//-------------------------------------------------------------------------//
//                                                                         //
//  This benchmark is a serial C version of the NPB CG code. This C        //
//  version is developed by the Center for Manycore Programming at Seoul   //
//  National University and derived from the serial Fortran versions in    //
//  "NPB3.3-SER" developed by NAS.                                         //
//                                                                         //
//  Permission to use, copy, distribute and modify this software for any   //
//  purpose with or without fee is hereby granted. This software is        //
//  provided "as is" without express or implied warranty.                  //
//                                                                         //
//  Information on NPB 3.3, including the technical report, the original   //
//  specifications, source code, results and information on how to submit  //
//  new results, is available at:                                          //
//                                                                         //
//           http://www.nas.nasa.gov/Software/NPB/                         //
//                                                                         //
//  Send comments or suggestions for this C version to cmp@aces.snu.ac.kr  //
//                                                                         //
//          Center for Manycore Programming                                //
//          School of Computer Science and Engineering                     //
//          Seoul National University                                      //
//          Seoul 151-744, Korea                                           //
//                                                                         //
//          E-mail:  cmp@aces.snu.ac.kr                                    //
//                                                                         //
//-------------------------------------------------------------------------//
//-------------------------------------------------------------------------//
// Authors: Sangmin Seo, Jungwon Kim, Jun Lee, Jeongho Nah, Gangwon Jo,    //
//          and Jaejin Lee                                                 //
//-------------------------------------------------------------------------//
//---------------------------------------------------------------------
// NPB CG serial version      
//---------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "globals.h"
#include "../common/randdp.h"
#include "../common/timers.h"
#include "../common/print_results.h"
//---------------------------------------------------------------------
/* common / main_int_mem / */
#include <omp.h> 
static int colidx[2016000];
static int rowstr[14001];
static int iv[14000];
static int arow[14000];
static int acol[168000];
/* common / main_flt_mem / */
static double aelt[168000];
static double a[2016000];
static double x[14002];
static double z[14002];
static double p[14002];
static double q[14002];
static double r[14002];
/* common / partit_size / */
static int naa;
static int nzz;
static int firstrow;
static int lastrow;
static int firstcol;
static int lastcol;
/* common /urando/ */
static double amult;
static double tran;
/* common /timers/ */
static logical timeron;
//---------------------------------------------------------------------
//---------------------------------------------------------------------
static void conj_grad(int colidx[],int rowstr[],double x[],double z[],double a[],double p[],double q[],double r[],double *rnorm);
static void makea(int n,int nz,double a[],int colidx[],int rowstr[],int firstrow,int lastrow,int firstcol,int lastcol,int arow[],int acol[][12],double aelt[][12],int iv[]);
static void sparse(double a[],int colidx[],int rowstr[],int n,int nz,int nozer,int arow[],int acol[][12],double aelt[][12],int firstrow,int lastrow,int nzloc[],double rcond,double shift);
static void sprnvc(int n,int nz,int nn1,double v[],int iv[]);
static int icnvrt(double x,int ipwr2);
static void vecset(int n,double v[],int iv[],int *nzv,int i,double val);
//---------------------------------------------------------------------

int main(int argc,char *argv[])
{
  int i;
  int j;
  int k;
  int it;
  double zeta;
  double rnorm;
  double norm_temp1;
  double norm_temp2;
  double t;
  double mflops;
  double tmax;
  char Class;
  logical verified;
  double zeta_verify_value;
  double epsilon;
  double err;
  char *t_names[3];
  for (i = 0; i <= 2; i += 1) {
    timer_clear(i);
  }
  FILE *fp;
  if ((fp = fopen("timer.flag","r")) != ((void *)0)) {
    timeron = true;
    t_names[0] = "init";
    t_names[1] = "benchmk";
    t_names[2] = "conjgd";
    fclose(fp);
  }
   else {
    timeron = false;
  }
  timer_start(0);
  firstrow = 0;
  lastrow = 14000 - 1;
  firstcol = 0;
  lastcol = 14000 - 1;
  if (14000 == 1400 && 11 == 7 && 15 == 15 && 20.0 == 10) {
    Class = 'S';
    zeta_verify_value = 8.5971775078648;
  }
   else if (14000 == 7000 && 11 == 8 && 15 == 15 && 20.0 == 12) {
    Class = 'W';
    zeta_verify_value = 10.362595087124;
  }
   else if (14000 == 14000 && 11 == 11 && 15 == 15 && 20.0 == 20) {
    Class = 'A';
    zeta_verify_value = 17.130235054029;
  }
   else if (14000 == 75000 && 11 == 13 && 15 == 75 && 20.0 == 60) {
    Class = 'B';
    zeta_verify_value = 22.712745482631;
  }
   else if (14000 == 150000 && 11 == 15 && 15 == 75 && 20.0 == 110) {
    Class = 'C';
    zeta_verify_value = 28.973605592845;
  }
   else if (14000 == 1500000 && 11 == 21 && 15 == 100 && 20.0 == 500) {
    Class = 'D';
    zeta_verify_value = 52.514532105794;
  }
   else if (14000 == 9000000 && 11 == 26 && 15 == 100 && 20.0 == 1500) {
    Class = 'E';
    zeta_verify_value = 77.522164599383;
  }
   else {
    Class = 'U';
  }
  printf("\n\n NAS Parallel Benchmarks (NPB3.3-SER-C) - CG Benchmark\n\n");
  printf(" Size: %11d\n",14000);
  printf(" Iterations: %5d\n",15);
  printf("\n");
  naa = 14000;
  nzz = 14000 * (11 + 1) * (11 + 1);
//---------------------------------------------------------------------
// Inialize random number generator
//---------------------------------------------------------------------
  tran = 314159265.0;
  amult = 1220703125.0;
  zeta = randlc(&tran,amult);
//---------------------------------------------------------------------
//  
//---------------------------------------------------------------------
  makea(naa,nzz,a,colidx,rowstr,firstrow,lastrow,firstcol,lastcol,arow,(int (*)[12])((void *)acol),(double (*)[12])((void *)aelt),iv);
//---------------------------------------------------------------------
// Note: as a result of the above call to makea:
//      values of j used in indexing rowstr go from 0 --> lastrow-firstrow
//      values of colidx which are col indexes go from firstcol --> lastcol
//      So:
//      Shift the col index vals from actual (firstcol --> lastcol ) 
//      to local, i.e., (0 --> lastcol-firstcol)
//---------------------------------------------------------------------
  for (j = 0; j <= lastrow - firstrow + 1 - 1; j += 1) {
    
#pragma omp parallel for private (k)
    for (k = rowstr[j]; k <= rowstr[j + 1] - 1; k += 1) {
      colidx[k] = colidx[k] - firstcol;
    }
  }
//---------------------------------------------------------------------
// set starting vector to (1, 1, .... 1)
//---------------------------------------------------------------------
  
#pragma omp parallel for private (i)
  for (i = 0; i <= 14000; i += 1) {
    x[i] = 1.0;
  }
  
#pragma omp parallel for private (j)
  for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
    q[j] = 0.0;
    z[j] = 0.0;
    r[j] = 0.0;
    p[j] = 0.0;
  }
  zeta = 0.0;
//---------------------------------------------------------------------
//---->
// Do one iteration untimed to init all code and data page tables
//---->                    (then reinit, start timing, to niter its)
//---------------------------------------------------------------------
  for (it = 1; it <= 1; it += 1) {
//---------------------------------------------------------------------
// The call to the conjugate gradient routine:
//---------------------------------------------------------------------
    conj_grad(colidx,rowstr,x,z,a,p,q,r,&rnorm);
//---------------------------------------------------------------------
// zeta = shift + 1/(x.z)
// So, first: (x.z)
// Also, find norm of z
// So, first: (z.z)
//---------------------------------------------------------------------
    norm_temp1 = 0.0;
    norm_temp2 = 0.0;
    
#pragma omp parallel for private (j) reduction (+:norm_temp1,norm_temp2)
    for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
      norm_temp1 = norm_temp1 + x[j] * z[j];
      norm_temp2 = norm_temp2 + z[j] * z[j];
    }
    norm_temp2 = 1.0 / sqrt(norm_temp2);
//---------------------------------------------------------------------
// Normalize z to obtain x
//---------------------------------------------------------------------
    
#pragma omp parallel for private (j) firstprivate (norm_temp2)
    for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
      x[j] = norm_temp2 * z[j];
    }
// end of do one iteration untimed
  }
//---------------------------------------------------------------------
// set starting vector to (1, 1, .... 1)
//---------------------------------------------------------------------
  
#pragma omp parallel for private (i)
  for (i = 0; i <= 14000; i += 1) {
    x[i] = 1.0;
  }
  zeta = 0.0;
  timer_stop(0);
  printf(" Initialization time = %15.3f seconds\n",(timer_read(0)));
  timer_start(1);
//---------------------------------------------------------------------
//---->
// Main Iteration for inverse power method
//---->
//---------------------------------------------------------------------
  for (it = 1; it <= 15; it += 1) {
//---------------------------------------------------------------------
// The call to the conjugate gradient routine:
//---------------------------------------------------------------------
    if (timeron) 
      timer_start(2);
    conj_grad(colidx,rowstr,x,z,a,p,q,r,&rnorm);
    if (timeron) 
      timer_stop(2);
//---------------------------------------------------------------------
// zeta = shift + 1/(x.z)
// So, first: (x.z)
// Also, find norm of z
// So, first: (z.z)
//---------------------------------------------------------------------
    norm_temp1 = 0.0;
    norm_temp2 = 0.0;
    
#pragma omp parallel for private (j) reduction (+:norm_temp1,norm_temp2)
    for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
      norm_temp1 = norm_temp1 + x[j] * z[j];
      norm_temp2 = norm_temp2 + z[j] * z[j];
    }
    norm_temp2 = 1.0 / sqrt(norm_temp2);
    zeta = 20.0 + 1.0 / norm_temp1;
    if (it == 1) 
      printf("\n   iteration           ||r||                 zeta\n");
    printf("    %5d       %20.14E%20.13f\n",it,rnorm,zeta);
//---------------------------------------------------------------------
// Normalize z to obtain x
//---------------------------------------------------------------------
    
#pragma omp parallel for private (j) firstprivate (norm_temp2)
    for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
      x[j] = norm_temp2 * z[j];
    }
// end of main iter inv pow meth
  }
  timer_stop(1);
//---------------------------------------------------------------------
// End of timed section
//---------------------------------------------------------------------
  t = timer_read(1);
  printf(" Benchmark completed\n");
  epsilon = 1.0e-10;
  if (Class != 'U') {
    err = fabs(zeta - zeta_verify_value) / zeta_verify_value;
    if (err <= epsilon) {
      verified = true;
      printf(" VERIFICATION SUCCESSFUL\n");
      printf(" Zeta is    %20.13E\n",zeta);
      printf(" Error is   %20.13E\n",err);
    }
     else {
      verified = false;
      printf(" VERIFICATION FAILED\n");
      printf(" Zeta                %20.13E\n",zeta);
      printf(" The correct zeta is %20.13E\n",zeta_verify_value);
    }
  }
   else {
    verified = false;
    printf(" Problem size unknown\n");
    printf(" NO VERIFICATION PERFORMED\n");
  }
  if (t != 0.0) {
    mflops = ((double )(2 * 15 * 14000)) * (3.0 + ((double )(11 * (11 + 1))) + 25.0 * (5.0 + ((double )(11 * (11 + 1)))) + 3.0) / t / 1000000.0;
  }
   else {
    mflops = 0.0;
  }
  print_results("CG",Class,14000,0,0,15,t,mflops,"          floating point",verified,"3.3.1","24 Apr 2020","gcc","$(CC)","-lm","-I../common","-g -Wall -O3 -fopenmp -mcmodel=medium","-O3 -fopenmp -mcmodel=medium","randdp");
//---------------------------------------------------------------------
// More timers
//---------------------------------------------------------------------
  if (timeron) {
    tmax = timer_read(1);
    if (tmax == 0.0) 
      tmax = 1.0;
    printf("  SECTION   Time (secs)\n");
    for (i = 0; i <= 2; i += 1) {
      t = timer_read(i);
      if (i == 0) {
        printf("  %8s:%9.3f\n",t_names[i],t);
      }
       else {
        printf("  %8s:%9.3f  (%6.2f%%)\n",t_names[i],t,t * 100.0 / tmax);
        if (i == 2) {
          t = tmax - t;
          printf("    --> %8s:%9.3f  (%6.2f%%)\n","rest",t,t * 100.0 / tmax);
        }
      }
    }
  }
  return 0;
}
//---------------------------------------------------------------------
// Floaging point arrays here are named as in NPB1 spec discussion of 
// CG algorithm
//---------------------------------------------------------------------

static void conj_grad(int colidx[],int rowstr[],double x[],double z[],double a[],double p[],double q[],double r[],double *rnorm)
{
  int j;
  int k;
  int cgit;
  int cgitmax = 25;
  double d;
  double sum;
  double rho;
  double rho0;
  double alpha;
  double beta;
  rho = 0.0;
//---------------------------------------------------------------------
// Initialize the CG algorithm:
//---------------------------------------------------------------------
  
#pragma omp parallel for private (j) firstprivate (naa)
  for (j = 0; j <= naa + 1 - 1; j += 1) {
    q[j] = 0.0;
    z[j] = 0.0;
    r[j] = x[j];
    p[j] = r[j];
  }
//---------------------------------------------------------------------
// rho = r.r
// Now, obtain the norm of r: First, sum squares of r elements locally...
//---------------------------------------------------------------------
  
#pragma omp parallel for private (j) reduction (+:rho)
  for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
    rho = rho + r[j] * r[j];
  }
//---------------------------------------------------------------------
//---->
// The conj grad iteration loop
//---->
//---------------------------------------------------------------------
  for (cgit = 1; cgit <= cgitmax; cgit += 1) {
//---------------------------------------------------------------------
// q = A.p
// The partition submatrix-vector multiply: use workspace w
//---------------------------------------------------------------------
//
// NOTE: this version of the multiply is actually (slightly: maybe %5) 
//       faster on the sp2 on 16 nodes than is the unrolled-by-2 version 
//       below.   On the Cray t3d, the reverse is true, i.e., the 
//       unrolled-by-two version is some 10% faster.  
//       The unrolled-by-8 version below is significantly faster
//       on the Cray t3d - overall speed of code is 1.5 times faster.
    
#pragma omp parallel for private (sum,j,k)
    for (j = 0; j <= lastrow - firstrow + 1 - 1; j += 1) {
      sum = 0.0;
      
#pragma omp parallel for private (k) reduction (+:sum)
      for (k = rowstr[j]; k <= rowstr[j + 1] - 1; k += 1) {
        sum = sum + a[k] * p[colidx[k]];
      }
      q[j] = sum;
    }
/*
    for (j = 0; j < lastrow - firstrow + 1; j++) {
      int i = rowstr[j];
      int iresidue = (rowstr[j+1] - i) % 2;
      double sum1 = 0.0;
      double sum2 = 0.0;
      if (iresidue == 1)
        sum1 = sum1 + a[i]*p[colidx[i]];
      for (k = i + iresidue; k <= rowstr[j+1] - 2; k += 2) {
        sum1 = sum1 + a[k]  *p[colidx[k]];
        sum2 = sum2 + a[k+1]*p[colidx[k+1]];
      }
      q[j] = sum1 + sum2;
    }
    */
/*
    for (j = 0; j < lastrow - firstrow + 1; j++) {
      int i = rowstr[j]; 
      int iresidue = (rowstr[j+1] - i) % 8;
      double sum = 0.0;
      for (k = i; k <= i + iresidue - 1; k++) {
        sum = sum + a[k]*p[colidx[k]];
      }
      for (k = i + iresidue; k <= rowstr[j+1] - 8; k += 8) {
        sum = sum + a[k  ]*p[colidx[k  ]]
                  + a[k+1]*p[colidx[k+1]]
                  + a[k+2]*p[colidx[k+2]]
                  + a[k+3]*p[colidx[k+3]]
                  + a[k+4]*p[colidx[k+4]]
                  + a[k+5]*p[colidx[k+5]]
                  + a[k+6]*p[colidx[k+6]]
                  + a[k+7]*p[colidx[k+7]];
      }
      q[j] = sum;
    }
    */
//---------------------------------------------------------------------
// Obtain p.q
//---------------------------------------------------------------------
    d = 0.0;
    
#pragma omp parallel for private (j) reduction (+:d)
    for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
      d = d + p[j] * q[j];
    }
//---------------------------------------------------------------------
// Obtain alpha = rho / (p.q)
//---------------------------------------------------------------------
    alpha = rho / d;
//---------------------------------------------------------------------
// Save a temporary of rho
//---------------------------------------------------------------------
    rho0 = rho;
//---------------------------------------------------------------------
// Obtain z = z + alpha*p
// and    r = r - alpha*q
//---------------------------------------------------------------------
    rho = 0.0;
    
#pragma omp parallel for private (j) firstprivate (alpha)
    for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
      z[j] = z[j] + alpha * p[j];
      r[j] = r[j] - alpha * q[j];
    }
//---------------------------------------------------------------------
// rho = r.r
// Now, obtain the norm of r: First, sum squares of r elements locally...
//---------------------------------------------------------------------
    
#pragma omp parallel for private (j) reduction (+:rho)
    for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
      rho = rho + r[j] * r[j];
    }
//---------------------------------------------------------------------
// Obtain beta:
//---------------------------------------------------------------------
    beta = rho / rho0;
//---------------------------------------------------------------------
// p = r + beta*p
//---------------------------------------------------------------------
    
#pragma omp parallel for private (j) firstprivate (beta)
    for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
      p[j] = r[j] + beta * p[j];
    }
// end of do cgit=1,cgitmax
  }
//---------------------------------------------------------------------
// Compute residual norm explicitly:  ||r|| = ||x - A.z||
// First, form A.z
// The partition submatrix-vector multiply
//---------------------------------------------------------------------
  sum = 0.0;
  
#pragma omp parallel for private (d,j,k) firstprivate (firstrow,lastrow)
  for (j = 0; j <= lastrow - firstrow + 1 - 1; j += 1) {
    d = 0.0;
    
#pragma omp parallel for private (k) reduction (+:d)
    for (k = rowstr[j]; k <= rowstr[j + 1] - 1; k += 1) {
      d = d + a[k] * z[colidx[k]];
    }
    r[j] = d;
  }
//---------------------------------------------------------------------
// At this point, r contains A.z
//---------------------------------------------------------------------
  
#pragma omp parallel for private (d,j) reduction (+:sum) firstprivate (firstcol,lastcol)
  for (j = 0; j <= lastcol - firstcol + 1 - 1; j += 1) {
    d = x[j] - r[j];
    sum = sum + d * d;
  }
   *rnorm = sqrt(sum);
}
//---------------------------------------------------------------------
// generate the test problem for benchmark 6
// makea generates a sparse matrix with a
// prescribed sparsity distribution
//
// parameter    type        usage
//
// input
//
// n            i           number of cols/rows of matrix
// nz           i           nonzeros as declared array size
// rcond        r*8         condition number
// shift        r*8         main diagonal shift
//
// output
//
// a            r*8         array for nonzeros
// colidx       i           col indices
// rowstr       i           row pointers
//
// workspace
//
// iv, arow, acol i
// aelt           r*8
//---------------------------------------------------------------------

static void makea(int n,int nz,double a[],int colidx[],int rowstr[],int firstrow,int lastrow,int firstcol,int lastcol,int arow[],int acol[][12],double aelt[][12],int iv[])
{
  int iouter;
  int ivelt;
  int nzv;
  int nn1;
  int ivc[12];
  double vc[12];
//---------------------------------------------------------------------
// nonzer is approximately  (int(sqrt(nnza /n)));
//---------------------------------------------------------------------
//---------------------------------------------------------------------
// nn1 is the smallest power of two not less than n
//---------------------------------------------------------------------
  nn1 = 1;
  do {
    nn1 = 2 * nn1;
  }while (nn1 < n);
//---------------------------------------------------------------------
// Generate nonzero positions and save for the use in sparse.
//---------------------------------------------------------------------
  for (iouter = 0; iouter <= n - 1; iouter += 1) {
    nzv = 11;
    sprnvc(n,nzv,nn1,vc,ivc);
    vecset(n,vc,ivc,&nzv,iouter + 1,0.5);
    arow[iouter] = nzv;
    
#pragma omp parallel for private (ivelt) firstprivate (nzv)
    for (ivelt = 0; ivelt <= nzv - 1; ivelt += 1) {
      acol[iouter][ivelt] = ivc[ivelt] - 1;
      aelt[iouter][ivelt] = vc[ivelt];
    }
  }
//---------------------------------------------------------------------
// ... make the sparse matrix from list of elements with duplicates
//     (iv is used as  workspace)
//---------------------------------------------------------------------
  sparse(a,colidx,rowstr,n,nz,11,arow,acol,aelt,firstrow,lastrow,iv,1.0e-1,20.0);
}
//---------------------------------------------------------------------
// rows range from firstrow to lastrow
// the rowstr pointers are defined for nrows = lastrow-firstrow+1 values
//---------------------------------------------------------------------

static void sparse(double a[],int colidx[],int rowstr[],int n,int nz,int nozer,int arow[],int acol[][12],double aelt[][12],int firstrow,int lastrow,int nzloc[],double rcond,double shift)
{
  int nrows;
//---------------------------------------------------
// generate a sparse matrix from a list of
// [col, row, element] tri
//---------------------------------------------------
  int i;
  int j;
  int j1;
  int j2;
  int nza;
  int k;
  int kk;
  int nzrow;
  int jcol;
  double size;
  double scale;
  double ratio;
  double va;
  logical cont40;
//---------------------------------------------------------------------
// how many rows of result
//---------------------------------------------------------------------
  nrows = lastrow - firstrow + 1;
//---------------------------------------------------------------------
// ...count the number of triples in each row
//---------------------------------------------------------------------
  
#pragma omp parallel for private (j)
  for (j = 0; j <= nrows + 1 - 1; j += 1) {
    rowstr[j] = 0;
  }
  for (i = 0; i <= n - 1; i += 1) {
    for (nza = 0; nza <= arow[i] - 1; nza += 1) {
      j = acol[i][nza] + 1;
      rowstr[j] = rowstr[j] + arow[i];
    }
  }
  rowstr[0] = 0;
  for (j = 1; j <= nrows + 1 - 1; j += 1) {
    rowstr[j] = rowstr[j] + rowstr[j - 1];
  }
  nza = rowstr[nrows] - 1;
//---------------------------------------------------------------------
// ... rowstr(j) now is the location of the first nonzero
//     of row j of a
//---------------------------------------------------------------------
  if (nza > nz) {
    printf("Space for matrix elements exceeded in sparse\n");
    printf("nza, nzmax = %d, %d\n",nza,nz);
    exit(1);
  }
//---------------------------------------------------------------------
// ... preload data pages
//---------------------------------------------------------------------
  for (j = 0; j <= nrows - 1; j += 1) {
    
#pragma omp parallel for private (k)
    for (k = rowstr[j]; k <= rowstr[j + 1] - 1; k += 1) {
      a[k] = 0.0;
      colidx[k] = - 1;
    }
    nzloc[j] = 0;
  }
//---------------------------------------------------------------------
// ... generate actual values by summing duplicates
//---------------------------------------------------------------------
  size = 1.0;
  ratio = pow(rcond,1.0 / ((double )n));
  for (i = 0; i <= n - 1; i += 1) {
    for (nza = 0; nza <= arow[i] - 1; nza += 1) {
      j = acol[i][nza];
      scale = size * aelt[i][nza];
      for (nzrow = 0; nzrow <= arow[i] - 1; nzrow += 1) {
        jcol = acol[i][nzrow];
        va = aelt[i][nzrow] * scale;
//--------------------------------------------------------------------
// ... add the identity * rcond to the generated matrix to bound
//     the smallest eigenvalue from below by rcond
//--------------------------------------------------------------------
        if (jcol == j && j == i) {
          va = va + rcond - shift;
        }
        cont40 = false;
        for (k = rowstr[j]; k <= rowstr[j + 1] - 1; k += 1) {
          if (colidx[k] > jcol) {
//----------------------------------------------------------------
// ... insert colidx here orderly
//----------------------------------------------------------------
            for (kk = rowstr[j + 1] - 2; kk >= k; kk += -1) {
              if (colidx[kk] > - 1) {
                a[kk + 1] = a[kk];
                colidx[kk + 1] = colidx[kk];
              }
            }
            colidx[k] = jcol;
            a[k] = 0.0;
            cont40 = true;
            break; 
          }
           else if (colidx[k] == - 1) {
            colidx[k] = jcol;
            cont40 = true;
            break; 
          }
           else if (colidx[k] == jcol) {
//--------------------------------------------------------------
// ... mark the duplicated entry
//--------------------------------------------------------------
            nzloc[j] = nzloc[j] + 1;
            cont40 = true;
            break; 
          }
        }
        if (cont40 == false) {
          printf("internal error in sparse: i=%d\n",i);
          exit(1);
        }
        a[k] = a[k] + va;
      }
    }
    size = size * ratio;
  }
//---------------------------------------------------------------------
// ... remove empty entries and generate final results
//---------------------------------------------------------------------
  for (j = 1; j <= nrows - 1; j += 1) {
    nzloc[j] = nzloc[j] + nzloc[j - 1];
  }
  for (j = 0; j <= nrows - 1; j += 1) {
    if (j > 0) {
      j1 = rowstr[j] - nzloc[j - 1];
    }
     else {
      j1 = 0;
    }
    j2 = rowstr[j + 1] - nzloc[j];
    nza = rowstr[j];
    for (k = j1; k <= j2 - 1; k += 1) {
      a[k] = a[nza];
      colidx[k] = colidx[nza];
      nza = nza + 1;
    }
  }
  
#pragma omp parallel for private (j)
  for (j = 1; j <= nrows + 1 - 1; j += 1) {
    rowstr[j] = rowstr[j] - nzloc[j - 1];
  }
  nza = rowstr[nrows] - 1;
}
//---------------------------------------------------------------------
// generate a sparse n-vector (v, iv)
// having nzv nonzeros
//
// mark(i) is set to 1 if position i is nonzero.
// mark is all zero on entry and is reset to all zero before exit
// this corrects a performance bug found by John G. Lewis, caused by
// reinitialization of mark on every one of the n calls to sprnvc
//---------------------------------------------------------------------

static void sprnvc(int n,int nz,int nn1,double v[],int iv[])
{
  int nzv;
  int ii;
  int i;
  double vecelt;
  double vecloc;
  nzv = 0;
  while(nzv < nz){
    vecelt = randlc(&tran,amult);
//---------------------------------------------------------------------
// generate an integer between 1 and n in a portable manner
//---------------------------------------------------------------------
    vecloc = randlc(&tran,amult);
    i = icnvrt(vecloc,nn1) + 1;
    if (i > n) 
      continue; 
//---------------------------------------------------------------------
// was this integer generated already?
//---------------------------------------------------------------------
    logical was_gen = false;
    for (ii = 0; ii <= nzv - 1; ii += 1) {
      if (iv[ii] == i) {
        was_gen = true;
        break; 
      }
    }
    if (was_gen) 
      continue; 
    v[nzv] = vecelt;
    iv[nzv] = i;
    nzv = nzv + 1;
  }
}
//---------------------------------------------------------------------
// scale a double precision number x in (0,1) by a power of 2 and chop it
//---------------------------------------------------------------------

static int icnvrt(double x,int ipwr2)
{
  return (int )(ipwr2 * x);
}
//---------------------------------------------------------------------
// set ith element of sparse vector (v, iv) with
// nzv nonzeros to val
//---------------------------------------------------------------------

static void vecset(int n,double v[],int iv[],int *nzv,int i,double val)
{
  int k;
  logical set;
  set = false;
  
#pragma omp parallel for private (k)
  for (k = 0; k <=  *nzv - 1; k += 1) {
    if (iv[k] == i) {
      v[k] = val;
      set = true;
    }
  }
  if (set == false) {
    v[ *nzv] = val;
    iv[ *nzv] = i;
     *nzv =  *nzv + 1;
  }
}
