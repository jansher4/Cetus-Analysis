/*
Copyright (C) 1991-2016 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it andor
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <http:www.gnu.org/licenses/>. 
*/
/*
This header is separate from features.h so that the compiler can
   include it implicitly at the start of every compilation.  It must
   not itself include <features.h> or any other header that includes
   <features.h> because the implicit include comes before any feature
   test macros that may be defined in a source file before it first
   explicitly includes a system header.  GCC knows the name of this
   header in order to preinclude it. 
*/
/*
glibc's intent is to support the IEC 559 math functionality, real
   and complex.  If the GCC (4.9 and later) predefined macros
   specifying compiler intent are available, use them to determine
   whether the overall intent is to support these features; otherwise,
   presume an older compiler has intent to support these features and
   define these macros by default. 
*/
/*
wchar_t uses Unicode 8.0.0.  Version 8.0 of the Unicode Standard is
   synchronized with ISOIEC 10646:2014, plus Amendment 1 (published
   2015-05-15). 
*/
/* We do not support C11 <threads.h>.  */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "adc.h"
#include "macrodef.h"
#include "protots.h"
#include <errno.h>
extern int32 computeChecksum(ADC_VIEW_CNTL * avp, treeNode * t, uint64 * ordern);
extern int32 WriteViewToDiskCS(ADC_VIEW_CNTL * avp, treeNode * t, uint64 * ordern);
int32 ReadWholeInputData(ADC_VIEW_CNTL * avp, FILE * inpf)
{
	uint32 iRec = 0;
	uint32 inpBufferLineSize, inpBufferPace, inpRecSize, ib = 0;
	fseek(inpf, 0, 0);
	;
	inpRecSize=((8*avp->nm)+(4*avp->nTopDims));
	inpBufferLineSize=inpRecSize;
	if (inpBufferLineSize%8)
	{
		inpBufferLineSize+=4;
	}
	inpBufferPace=(inpBufferLineSize/4);
	while (fread( & avp->inpDataBuffer[ib], inpRecSize, 1, inpf))
	{
		iRec ++ ;
		ib+=inpBufferPace;
	}
	avp->nRowsToRead=iRec;
	fseek(inpf, 0, 0);
	;
	if (avp->nInputRecs!=iRec)
	{
		fprintf(stderr, " ReadWholeInputData(): wrong input data reading.\n");
		return 2;
	}
	return 0;
}

int32 ComputeMemoryFittedView(ADC_VIEW_CNTL * avp)
{
	uint32 iRec = 0;
	uint32 viewBuf[(20+(2*4))];
	uint32 inpBufferLineSize, inpBufferPace, inpRecSize, ib;
	uint64 ordern = 0;
	fseek(avp->viewFile, 0, 2);
	;
	inpRecSize=((8*avp->nm)+(4*avp->nTopDims));
	inpBufferLineSize=inpRecSize;
	if (inpBufferLineSize%8)
	{
		inpBufferLineSize+=4;
	}
	inpBufferPace=(inpBufferLineSize/4);
	InitializeTree(avp->tree, avp->nv, avp->nm);
	ib=0;
	#pragma loop name ComputeMemoryFittedView#0 
	for (iRec=1; iRec<=avp->nRowsToRead; iRec ++ )
	{
		SelectToView( & avp->inpDataBuffer[ib], avp->selection, viewBuf, avp->nd, avp->nm, avp->nv);
		ib+=inpBufferPace;
		TreeInsert(avp->tree, viewBuf);
		if (avp->tree->memoryIsFull)
		{
			fprintf(stderr, "ComputeMemoryFittedView(): Not enough memory.\n");
			return 1;
		}
	}
	computeChecksum(avp, avp->tree->root.left,  & ordern);
	avp->nViewRows=avp->tree->count;
	avp->totalOfViewRows+=avp->nViewRows;
	InitializeTree(avp->tree, avp->nv, avp->nm);
	return 0;
}

int32 SharedSortAggregate(ADC_VIEW_CNTL * avp)
{
	int32 retCode;
	uint32 iRec = 0;
	uint32 attrs[(20+(2*4))];
	uint32 currBuf[(20+(2*4))];
	int64 chunkOffset = 0;
	int64 inpfOffset;
	uint32 nPart = 0;
	uint32 prevV;
	uint32 currV;
	uint32 total = 0;
	unsigned char * ib;
	uint32 ibsize = 1024*1024;
	uint32 nib;
	uint32 iib;
	uint32 nreg;
	uint32 nlst;
	uint32 nsgs;
	uint32 ncur;
	uint32 ibOffset = 0;
	uint64 ordern = 0;
	ib=((unsigned char * )malloc(ibsize));
	if ( ! ib)
	{
		fprintf(stderr, "SharedSortAggregate: memory allocation failed\n");
		return 5;
	}
	nib=(ibsize/avp->inpRecSize);
	nsgs=(avp->nRowsToRead/nib);
	if (nsgs==0)
	{
		nreg=avp->nRowsToRead;
		nlst=nreg;
		nsgs=1;
	}
	else
	{
		nreg=nib;
		if (avp->nRowsToRead%nib)
		{
			nsgs ++ ;
			nlst=(avp->nRowsToRead%nib);
		}
		else
		{
			nlst=nreg;
		}
	}
	avp->nViewRows=0;
	#pragma loop name SharedSortAggregate#0 
	/* #pragma cetus reduction(+: avp->nViewRows, total)  */
	for (iib=1; iib<=nsgs; iib ++ )
	{
		if (iib>1)
		{
			fseek(avp->viewFile, inpfOffset, 0);
		}
		;
		if (iib==nsgs)
		{
			ncur=nlst;
		}
		else
		{
			ncur=nreg;
		}
		fread(ib, ncur*avp->inpRecSize, 1, avp->viewFile);
		inpfOffset=ftell(avp->viewFile);
		#pragma loop name SharedSortAggregate#0#0 
		/* #pragma cetus reduction(+: avp->nViewRows, total)  */
		for (((ibOffset=0), (iRec=1)); iRec<=ncur; iRec ++ )
		{
			memcpy(attrs,  & ib[ibOffset], avp->inpRecSize);
			ibOffset+=avp->inpRecSize;
			SelectToView(attrs, avp->selection, currBuf, avp->nd, avp->nm, avp->nv);
			currV=currBuf[2*avp->nm];
			if ((iib==1)&&(iRec==1))
			{
				prevV=currV;
				nPart=1;
				InitializeTree(avp->tree, avp->nv, avp->nm);
				TreeInsert(avp->tree, currBuf);
			}
			else
			{
				if (currV==prevV)
				{
					nPart ++ ;
					TreeInsert(avp->tree, currBuf);
					if (avp->tree->memoryIsFull)
					{
						avp->chunksParams[avp->numberOfChunks].curChunkNum=avp->tree->count;
						avp->chunksParams[avp->numberOfChunks].chunkOffset=chunkOffset;
						avp->numberOfChunks ++ ;
						if (avp->numberOfChunks>=1024)
						{
							fprintf(stderr, "Too many chunks were created.\n");
							exit(1);
						}
						chunkOffset+=((uint64)(avp->tree->count*avp->outRecSize));
						retCode=WriteChunkToDisk(avp->outRecSize, avp->fileOfChunks, avp->tree->root.left, avp->logf);
						if (retCode!=0)
						{
							fprintf(stderr, "SharedSortAggregate: Write error occured.\n");
							return retCode;
						}
						InitializeTree(avp->tree, avp->nv, avp->nm);
					}
					/* memoryIsFull */
				}
				else
				{
					if (avp->numberOfChunks&&(avp->tree->count!=0))
					{
						avp->chunksParams[avp->numberOfChunks].curChunkNum=avp->tree->count;
						avp->chunksParams[avp->numberOfChunks].chunkOffset=chunkOffset;
						avp->numberOfChunks ++ ;
						chunkOffset+=((uint64)(avp->tree->count*((4*avp->nv)+(8*avp->nm))));
						retCode=WriteChunkToDisk(avp->outRecSize, avp->fileOfChunks, avp->tree->root.left, avp->logf);
						if (retCode!=0)
						{
							fprintf(stderr, "SharedSortAggregate: Write error occured.\n");
							return retCode;
						}
					}
					fseek(avp->viewFile, 0, 2);
					;
					if ( ! avp->numberOfChunks)
					{
						avp->nViewRows+=avp->tree->count;
						retCode=WriteViewToDiskCS(avp, avp->tree->root.left,  & ordern);
						if (retCode!=0)
						{
							fprintf(stderr, "SharedSortAggregate: Write error occured.\n");
							return retCode;
						}
					}
					else
					{
						retCode=MultiWayMerge(avp);
						if (retCode!=0)
						{
							fprintf(stderr, "SharedSortAggregate.MultiWayMerge: failed.\n");
							return retCode;
						}
					}
					InitializeTree(avp->tree, avp->nv, avp->nm);
					TreeInsert(avp->tree, currBuf);
					total+=nPart;
					nPart=1;
				}
			}
			prevV=currV;
		}
		/* iRec */
	}
	/* iib */
	if (avp->numberOfChunks&&(avp->tree->count!=0))
	{
		avp->chunksParams[avp->numberOfChunks].curChunkNum=avp->tree->count;
		avp->chunksParams[avp->numberOfChunks].chunkOffset=chunkOffset;
		avp->numberOfChunks ++ ;
		chunkOffset+=((uint64)(avp->tree->count*((4*avp->nv)+(8*avp->nm))));
		retCode=WriteChunkToDisk(avp->outRecSize, avp->fileOfChunks, avp->tree->root.left, avp->logf);
		if (retCode!=0)
		{
			fprintf(stderr, "SharedSortAggregate: Write error occured.\n");
			return retCode;
		}
	}
	fseek(avp->viewFile, 0, 2);
	;
	if ( ! avp->numberOfChunks)
	{
		avp->nViewRows+=avp->tree->count;
		if (retCode=WriteViewToDiskCS(avp, avp->tree->root.left,  & ordern))
		{
			fprintf(stderr, "SharedSortAggregate: Write error occured.\n");
			return retCode;
		}
	}
	else
	{
		retCode=MultiWayMerge(avp);
		if (retCode!=0)
		{
			fprintf(stderr, "SharedSortAggregate.MultiWayMerge failed.\n");
			return retCode;
		}
	}
	fseek(avp->fileOfChunks, 0, 0);
	;
	total+=nPart;
	avp->totalOfViewRows+=avp->nViewRows;
	if (ib)
	{
		free(ib);
	}
	return 0;
}

int32 PrefixedAggregate(ADC_VIEW_CNTL * avp, FILE * iof)
{
	uint32 i;
	uint32 iRec = 0;
	uint32 attrs[(20+(2*4))];
	uint32 aggrBuf[(20+(2*4))];
	uint32 currBuf[(20+(2*4))];
	uint32 prevBuf[(20+(2*4))];
	int64 * aggrmp;
	int64 * currmp;
	int32 compRes;
	uint32 nOut = 0;
	uint32 mpOffset = 0;
	uint32 nOutBufRecs;
	uint32 nViewRows = 0;
	int64 inpfOffset;
	aggrmp=((int64 * )( & aggrBuf[0]));
	currmp=((int64 * )( & currBuf[0]));
	#pragma loop name PrefixedAggregate#0 
	#pragma cetus parallel 
	#pragma omp parallel for
	for (i=0; i<((2*avp->nm)+avp->nv); i ++ )
	{
		prevBuf[i]=0;
		aggrBuf[i]=0;
	}
	nOutBufRecs=(avp->memoryLimit/avp->outRecSize);
	#pragma loop name PrefixedAggregate#1 
	/* #pragma cetus reduction(+: nViewRows)  */
	for (iRec=1; iRec<=avp->nRowsToRead; iRec ++ )
	{
		fread(attrs, avp->inpRecSize, 1, iof);
		SelectToView(attrs, avp->selection, currBuf, avp->nd, avp->nm, avp->nv);
		if (iRec==1)
		{
			memcpy(aggrBuf, currBuf, avp->outRecSize);
		}
		else
		{
			compRes=KeyComp( & currBuf[2*avp->nm],  & prevBuf[2*avp->nm], avp->nv);
			switch (compRes)
			{
				case 1:
				memcpy( & avp->memPool[mpOffset], aggrBuf, avp->outRecSize);
				mpOffset+=avp->outRecSize;
				nOut ++ ;
				#pragma loop name PrefixedAggregate#1#0 
				#pragma cetus parallel 
				#pragma omp parallel for
				for (i=0; i<avp->nm; i ++ )
				{
					avp->mSums[i]+=aggrmp[i];
					avp->checksums[i]+=((nOut*aggrmp[i])%measbound);
				}
				memcpy(aggrBuf, currBuf, avp->outRecSize);
				break;
				case 0:
				#pragma loop name PrefixedAggregate#1#1 
				#pragma cetus parallel 
				#pragma omp parallel for
				for (i=0; i<avp->nm; i ++ )
				{
					aggrmp[i]+=currmp[i];
				}
				break;
				case ( - 1):
				fprintf(stderr, "PrefixedAggregate: wrong parent view order.\n");
				exit(1);
				break;
				default:
				fprintf(stderr, "PrefixedAggregate: wrong KeyComp() result.\n");
				exit(1);
				break;
			}
			if (nOut==nOutBufRecs)
			{
				inpfOffset=ftell(iof);
				fseek(iof, 0, 2);
				;
				if (fwrite(avp->memPool, nOut*avp->outRecSize, 1, iof)!=1)
				{
					fprintf(stderr, "\n Write error from WriteToFile()\n");
					return 1;
				}
				;
				fseek(iof, inpfOffset, 0);
				;
				mpOffset=0;
				nViewRows+=nOut;
				nOut=0;
			}
		}
		memcpy(prevBuf, currBuf, avp->outRecSize);
	}
	memcpy( & avp->memPool[mpOffset], aggrBuf, avp->outRecSize);
	nOut ++ ;
	#pragma loop name PrefixedAggregate#2 
	#pragma cetus parallel 
	#pragma omp parallel for
	for (i=0; i<avp->nm; i ++ )
	{
		avp->mSums[i]+=aggrmp[i];
		avp->checksums[i]+=((nOut*aggrmp[i])%measbound);
	}
	fseek(iof, 0, 2);
	;
	if (fwrite(avp->memPool, nOut*avp->outRecSize, 1, iof)!=1)
	{
		fprintf(stderr, "\n Write error from WriteToFile()\n");
		return 1;
	}
	;
	avp->nViewRows=(nViewRows+nOut);
	avp->totalOfViewRows+=avp->nViewRows;
	return 0;
}

int32 RunFormation(ADC_VIEW_CNTL * avp, FILE * inpf)
{
	uint32 iRec = 0;
	uint32 viewBuf[(20+(2*4))];
	uint32 attrs[(20+(2*4))];
	int64 chunkOffset = 0;
	InitializeTree(avp->tree, avp->nv, avp->nm);
	#pragma loop name RunFormation#0 
	for (iRec=1; iRec<=avp->nRowsToRead; iRec ++ )
	{
		fread(attrs, avp->inpRecSize, 1, inpf);
		SelectToView(attrs, avp->selection, viewBuf, avp->nd, avp->nm, avp->nv);
		TreeInsert(avp->tree, viewBuf);
		if (avp->tree->memoryIsFull)
		{
			avp->chunksParams[avp->numberOfChunks].curChunkNum=avp->tree->count;
			avp->chunksParams[avp->numberOfChunks].chunkOffset=chunkOffset;
			avp->numberOfChunks ++ ;
			if (avp->numberOfChunks>=1024)
			{
				fprintf(stderr, "RunFormation: Too many chunks were created.\n");
				return 2;
			}
			chunkOffset+=((uint64)(avp->tree->count*avp->outRecSize));
			if (WriteChunkToDisk(avp->outRecSize, avp->fileOfChunks, avp->tree->root.left, avp->logf))
			{
				fprintf(stderr, "RunFormation.WriteChunkToDisk: Write error is occured.\n");
				return 1;
			}
			InitializeTree(avp->tree, avp->nv, avp->nm);
		}
	}
	/* Insertion ... */
	if (avp->numberOfChunks&&(avp->tree->count!=0))
	{
		avp->chunksParams[avp->numberOfChunks].curChunkNum=avp->tree->count;
		avp->chunksParams[avp->numberOfChunks].chunkOffset=chunkOffset;
		avp->numberOfChunks ++ ;
		chunkOffset+=((uint64)(avp->tree->count*((4*avp->nv)+(8*avp->nm))));
		if (WriteChunkToDisk(avp->outRecSize, avp->fileOfChunks, avp->tree->root.left, avp->logf))
		{
			fprintf(stderr, "RunFormation(.WriteChunkToDisk: Write error is occured.\n");
			return 1;
		}
	}
	fseek(avp->viewFile, 0, 2);
	;
	return 0;
}

void SeekAndReadNextSubChunk(uint32 multiChunkBuffer[], uint32 k, FILE * inFile, uint32 chunkRecSize, uint64 inFileOffs, uint32 subChunkNum)
{
	int64 ret;
	ret=fseek(inFile, inFileOffs, 0);
	;
	if (ret<0)
	{
		fprintf(stderr, "SeekAndReadNextSubChunk.fseek() < 0 ");
		exit(1);
	}
	fread( & multiChunkBuffer[k], chunkRecSize*subChunkNum, 1, inFile);
}

void ReadSubChunk(uint32 chunkRecSize, uint32 * multiChunkBuffer, uint32 mwBufRecSizeInInt, uint32 iChunk, uint32 regSubChunkSize, CHUNKS * chunks, FILE * fileOfChunks)
{
	if (chunks[iChunk].curChunkNum>0)
	{
		if (chunks[iChunk].curChunkNum<regSubChunkSize)
		{
			SeekAndReadNextSubChunk(multiChunkBuffer, ((iChunk*regSubChunkSize)+(regSubChunkSize-chunks[iChunk].curChunkNum))*mwBufRecSizeInInt, fileOfChunks, chunkRecSize, chunks[iChunk].chunkOffset, chunks[iChunk].curChunkNum);
			chunks[iChunk].posSubChunk=(regSubChunkSize-chunks[iChunk].curChunkNum);
			chunks[iChunk].curSubChunk=chunks[iChunk].curChunkNum;
			chunks[iChunk].curChunkNum=0;
			chunks[iChunk].chunkOffset=( - 1);
		}
		else
		{
			SeekAndReadNextSubChunk(multiChunkBuffer, (iChunk*regSubChunkSize)*mwBufRecSizeInInt, fileOfChunks, chunkRecSize, chunks[iChunk].chunkOffset, regSubChunkSize);
			chunks[iChunk].posSubChunk=0;
			chunks[iChunk].curSubChunk=regSubChunkSize;
			chunks[iChunk].curChunkNum-=regSubChunkSize;
			chunks[iChunk].chunkOffset+=(regSubChunkSize*chunkRecSize);
		}
	}
}

int32 MultiWayMerge(ADC_VIEW_CNTL * avp)
{
	uint32 outputBuffer[(20+((8/4)*4))];
	uint32 r_buf[(20+((8/4)*4))];
	uint32 min_r_buf[(20+((8/4)*4))];
	uint32 first_one;
	uint32 i;
	uint32 iChunk;
	uint32 min_r_chunk;
	uint32 sPos;
	uint32 iPos;
	uint32 numEmptyBufs;
	uint32 numEmptyRuns;
	uint32 mwBufRecSizeInInt;
	uint32 chunkRecSize;
	uint32 * multiChunkBuffer;
	uint32 regSubChunkSize;
	int32 compRes;
	int64 * m_min_r_buf;
	int64 * m_outputBuffer;
	fseek(avp->fileOfChunks, 0, 0);
	;
	multiChunkBuffer=((uint32 * )( & avp->memPool[0]));
	first_one=1;
	avp->nViewRows=0;
	chunkRecSize=avp->outRecSize;
	mwBufRecSizeInInt=(chunkRecSize/4);
	m_min_r_buf=((int64 * )( & min_r_buf[0]));
	m_outputBuffer=((int64 * )( & outputBuffer[0]));
	mwBufRecSizeInInt=(chunkRecSize/4);
	regSubChunkSize=((avp->memoryLimit/avp->numberOfChunks)/chunkRecSize);
	if (regSubChunkSize==0)
	{
		fprintf(stderr, "MultiWayMerge: Not enough memory to run the external sort\n");
		return 2;
	}
	multiChunkBuffer=((uint32 * )( & avp->memPool[0]));
	#pragma loop name MultiWayMerge#0 
	for (i=0; i<avp->numberOfChunks; i ++ )
	{
		ReadSubChunk(chunkRecSize, multiChunkBuffer, mwBufRecSizeInInt, i, regSubChunkSize, avp->chunksParams, avp->fileOfChunks);
	}
	while (1)
	{
		#pragma loop name MultiWayMerge#1 
		for (iChunk=0; iChunk<avp->numberOfChunks; iChunk ++ )
		{
			if (avp->chunksParams[iChunk].curSubChunk>0)
			{
				sPos=((iChunk*regSubChunkSize)*mwBufRecSizeInInt);
				iPos=(sPos+(mwBufRecSizeInInt*avp->chunksParams[iChunk].posSubChunk));
				memcpy( & min_r_buf[0],  & multiChunkBuffer[iPos], avp->outRecSize);
				min_r_chunk=iChunk;
				break;
			}
		}
		#pragma loop name MultiWayMerge#2 
		for (iChunk=min_r_chunk; iChunk<avp->numberOfChunks; iChunk ++ )
		{
			uint32 iPos;
			if (avp->chunksParams[iChunk].curSubChunk>0)
			{
				iPos=(mwBufRecSizeInInt*((iChunk*regSubChunkSize)+avp->chunksParams[iChunk].posSubChunk));
				memcpy( & r_buf[0],  & multiChunkBuffer[iPos], avp->outRecSize);
				compRes=KeyComp( & r_buf[2*avp->nm],  & min_r_buf[2*avp->nm], avp->nv);
				if (compRes<0)
				{
					memcpy( & min_r_buf[0],  & r_buf[0], avp->outRecSize);
					min_r_chunk=iChunk;
				}
			}
		}
		/* Step forward */
		if (avp->chunksParams[min_r_chunk].curSubChunk!=0)
		{
			avp->chunksParams[min_r_chunk].curSubChunk -- ;
			avp->chunksParams[min_r_chunk].posSubChunk ++ ;
		}
		/* Aggreagation if a duplicate is encountered */
		if (first_one)
		{
			memcpy( & outputBuffer[0],  & min_r_buf[0], avp->outRecSize);
			first_one=0;
		}
		else
		{
			compRes=KeyComp( & outputBuffer[2*avp->nm],  & min_r_buf[2*avp->nm], avp->nv);
			if ( ! compRes)
			{
				#pragma loop name MultiWayMerge#3 
				#pragma cetus parallel 
				#pragma omp parallel for
				for (i=0; i<avp->nm; i ++ )
				{
					m_outputBuffer[i]+=m_min_r_buf[i];
				}
			}
			else
			{
				if (fwrite(outputBuffer, avp->outRecSize, 1, avp->viewFile)!=1)
				{
					fprintf(stderr, "\n Write error from WriteToFile()\n");
					return 1;
				}
				;
				avp->nViewRows ++ ;
				#pragma loop name MultiWayMerge#4 
				#pragma cetus parallel 
				#pragma omp parallel for
				for (i=0; i<avp->nm; i ++ )
				{
					avp->mSums[i]+=m_outputBuffer[i];
					avp->checksums[i]+=((avp->nViewRows*m_outputBuffer[i])%measbound);
				}
				memcpy( & outputBuffer[0],  & min_r_buf[0], avp->outRecSize);
			}
		}
		#pragma loop name MultiWayMerge#5 
		for (((numEmptyBufs=0), (numEmptyRuns=0), (i=0)); i<avp->numberOfChunks; i ++ )
		{
			if (avp->chunksParams[i].curSubChunk==0)
			{
				numEmptyBufs ++ ;
			}
			if (avp->chunksParams[i].curChunkNum==0)
			{
				numEmptyRuns ++ ;
			}
		}
		if ((numEmptyBufs==avp->numberOfChunks)&&(numEmptyRuns==avp->numberOfChunks))
		{
			break;
		}
		if (avp->chunksParams[min_r_chunk].curSubChunk==0)
		{
			ReadSubChunk(chunkRecSize, multiChunkBuffer, mwBufRecSizeInInt, min_r_chunk, regSubChunkSize, avp->chunksParams, avp->fileOfChunks);
		}
	}
	/* while(1) */
	if (fwrite(outputBuffer, avp->outRecSize, 1, avp->viewFile)!=1)
	{
		fprintf(stderr, "\n Write error from WriteToFile()\n");
		return 1;
	}
	;
	avp->nViewRows ++ ;
	#pragma loop name MultiWayMerge#6 
	#pragma cetus parallel 
	#pragma omp parallel for
	for (i=0; i<avp->nm; i ++ )
	{
		avp->mSums[i]+=m_outputBuffer[i];
		avp->checksums[i]+=((avp->nViewRows*m_outputBuffer[i])%measbound);
	}
	avp->totalOfViewRows+=avp->nViewRows;
	return 0;
}

void SelectToView(uint32 * ib, uint32 * ix, uint32 * viewBuf, uint32 nd, uint32 nm, uint32 nv)
{
	uint32 i, j;
	#pragma loop name SelectToView#0 
	for (((j=0), (i=0)); i<nv; i ++ )
	{
		viewBuf[(2*nm)+(j ++ )]=ib[((2*nm)+ix[i])-1];
	}
	memcpy( & viewBuf[0],  & ib[0], 8*nm);
}

FILE *AdcFileOpen(const char * fileName, const char * mode)
{
	FILE * fr;
	if ((fr=((FILE * )fopen(fileName, mode)))==((void * )0))
	{
		fprintf(stderr, "AdcFileOpen: Cannot open the file %s errno = %d\n", fileName,  * __errno_location());
	}
	return fr;
}

void AdcFileName(char * adcFileName, const char * adcName, const char * fileName, uint32 taskNumber)
{
	sprintf(adcFileName, "%s.%s.%d", adcName, fileName, taskNumber);
}

ADC_VIEW_CNTL *NewAdcViewCntl(ADC_VIEW_PARS * adcpp, uint32 pnum)
{
	ADC_VIEW_CNTL * adccntl;
	uint32 i, j, k;
	uint32 ux;
	char id[(8+1)];
	adccntl=((ADC_VIEW_CNTL * )malloc(sizeof (ADC_VIEW_CNTL)));
	if (adccntl==((void * )0))
	{
		return ((void * )0);
	}
	adccntl->ndid=adcpp->ndid;
	adccntl->taskNumber=pnum;
	adccntl->retCode=0;
	adccntl->swapIt=0;
	strcpy(adccntl->adcName, adcpp->adcName);
	adccntl->nTopDims=adcpp->nd;
	adccntl->nd=adcpp->nd;
	adccntl->nm=adcpp->nm;
	adccntl->nInputRecs=adcpp->nInputRecs;
	adccntl->inpRecSize=((4*adccntl->nd)+(8*adccntl->nm));
	adccntl->outRecSize=((4*adccntl->nv)+(8*adccntl->nm));
	adccntl->accViewFileOffset=0;
	adccntl->totalViewFileSize=0;
	adccntl->numberOfMadeViews=0;
	adccntl->numberOfViewsMadeFromInput=0;
	adccntl->numberOfPrefixedGroupbys=0;
	adccntl->numberOfSharedSortGroupbys=0;
	adccntl->totalOfViewRows=0;
	adccntl->memoryLimit=adcpp->memoryLimit;
	adccntl->nTasks=adcpp->nTasks;
	strcpy(adccntl->inpFileName, adcpp->adcInpFileName);
	sprintf(id, ".%d", adcpp->ndid);
	AdcFileName(adccntl->adcLogFileName, adccntl->adcName, "logf", adccntl->taskNumber);
	strcat(adccntl->adcLogFileName, id);
	adccntl->logf=AdcFileOpen(adccntl->adcLogFileName, "w");
	AdcFileName(adccntl->inpFileName, adccntl->adcName, "dat", adcpp->ndid);
	adccntl->inpf=AdcFileOpen(adccntl->inpFileName, "rb");
	if ( ! adccntl->inpf)
	{
		adccntl->retCode=4;
		return adccntl;
	}
	AdcFileName(adccntl->viewFileName, adccntl->adcName, "view.dat", adccntl->taskNumber);
	strcat(adccntl->viewFileName, id);
	adccntl->viewFile=AdcFileOpen(adccntl->viewFileName, "wb+");
	AdcFileName(adccntl->chunksFileName, adccntl->adcName, "chunks.dat", adccntl->taskNumber);
	strcat(adccntl->chunksFileName, id);
	adccntl->fileOfChunks=AdcFileOpen(adccntl->chunksFileName, "wb+");
	AdcFileName(adccntl->groupbyFileName, adccntl->adcName, "groupby.dat", adccntl->taskNumber);
	strcat(adccntl->groupbyFileName, id);
	adccntl->groupbyFile=AdcFileOpen(adccntl->groupbyFileName, "wb+");
	AdcFileName(adccntl->adcViewSizesFileName, adccntl->adcName, "view.sz", adcpp->ndid);
	adccntl->adcViewSizesFile=AdcFileOpen(adccntl->adcViewSizesFileName, "r");
	if ( ! adccntl->adcViewSizesFile)
	{
		adccntl->retCode=4;
		return adccntl;
	}
	AdcFileName(adccntl->viewSizesFileName, adccntl->adcName, "viewsz.dat", adccntl->taskNumber);
	strcat(adccntl->viewSizesFileName, id);
	adccntl->viewSizesFile=AdcFileOpen(adccntl->viewSizesFileName, "wb+");
	adccntl->chunksParams=((CHUNKS * )malloc(1024*sizeof (CHUNKS)));
	if (adccntl->chunksParams==((void * )0))
	{
		fprintf(adccntl->logf, "NewAdcViewCntl: Cannot allocate 'chunksParsms'\n");
		adccntl->retCode=5;
		return adccntl;
	}
	adccntl->memPool=((unsigned char * )malloc(adccntl->memoryLimit));
	if (adccntl->memPool==((void * )0))
	{
		fprintf(adccntl->logf, "NewAdcViewCntl: Cannot allocate 'main memory pool'\n");
		adccntl->retCode=5;
		return adccntl;
	}
	/* add a condition to allocate this memory buffer, THIS is IMPORTANT */
	ux=((4*adccntl->nTopDims)+(8*adccntl->nm));
	if (adccntl->nTopDims%8)
	{
		ux+=4;
	}
	adccntl->inpDataBuffer=((uint32 * )malloc(adccntl->nInputRecs*ux));
	if (adccntl->inpDataBuffer==((void * )0))
	{
		fprintf(adccntl->logf, "NewAdcViewCntl: Cannot allocate 'input data buffer'\n");
		adccntl->retCode=5;
		return adccntl;
	}
	adccntl->numberOfChunks=0;
	#pragma loop name NewAdcViewCntl#0 
	#pragma cetus parallel 
	#pragma omp parallel for
	for (i=0; i<adccntl->nm; i ++ )
	{
		adccntl->mSums[i]=0;
		adccntl->checksums[i]=0;
		adccntl->totchs[i]=0;
	}
	adccntl->tree=CreateEmptyTree(adccntl->nd, adccntl->nm, adccntl->memoryLimit, adccntl->memPool);
	if ( ! adccntl->tree)
	{
		fprintf(adccntl->logf, "\nNewAdcViewCntl.CreateEmptyTree failed.\n");
		adccntl->retCode=5;
		return adccntl;
	}
	adccntl->nv=adcpp->nd;
	/* default */
	#pragma loop name NewAdcViewCntl#1 
	#pragma cetus parallel 
	#pragma omp parallel for
	for (i=0; i<adccntl->nv; i ++ )
	{
		adccntl->selection[i]=(i+1);
	}
	adccntl->nViewLimit=((1<<adcpp->nd)-1);
	adccntl->jpp=((JOB_POOL * )malloc((adccntl->nViewLimit+1)*sizeof (JOB_POOL)));
	if (adccntl->jpp==((void * )0))
	{
		fprintf(adccntl->logf, "\n Not enough space to allocate %ld byte for a job pool.", ((long)(adccntl->nViewLimit+1))*sizeof (JOB_POOL));
		adccntl->retCode=5;
		return adccntl;
	}
	adccntl->lpp=((LAYER * )malloc((adcpp->nd+1)*sizeof (LAYER)));
	if (adccntl->lpp==((void * )0))
	{
		fprintf(adccntl->logf, "\n Not enough space to allocate %ld byte for a layer reference array.", ((long)(adcpp->nd+1))*sizeof (LAYER));
		adccntl->retCode=5;
		return adccntl;
	}
	#pragma loop name NewAdcViewCntl#2 
	for (((j=1), (i=1)); i<=adcpp->nd; i ++ )
	{
		k=NumOfCombsFromNbyK(adcpp->nd, i);
		adccntl->lpp[i].layerIndex=j;
		j+=k;
		adccntl->lpp[i].layerQuantityLimit=k;
		adccntl->lpp[i].layerCurrentPopulation=0;
	}
	JobPoolInit(adccntl->jpp, adccntl->nViewLimit+1, adcpp->nd);
	fprintf(adccntl->logf, "\nMeaning of the log file colums is as follows:\n");
	fprintf(adccntl->logf, "Row Number | Groupby | View Size | Measure Sums | Number of Chunks\n");
	adccntl->verificationFailed=1;
	return adccntl;
}

void InitAdcViewCntl(ADC_VIEW_CNTL * adccntl, uint32 nSelectedDims, uint32 * selection, uint32 fromParent)
{
	uint32 i;
	adccntl->nv=nSelectedDims;
	#pragma loop name InitAdcViewCntl#0 
	#pragma cetus parallel 
	#pragma omp parallel for
	for (i=0; i<adccntl->nm; i ++ )
	{
		adccntl->mSums[i]=0;
	}
	#pragma loop name InitAdcViewCntl#1 
	#pragma cetus parallel 
	#pragma omp parallel for
	for (i=0; i<adccntl->nv; i ++ )
	{
		adccntl->selection[i]=selection[i];
	}
	adccntl->outRecSize=((4*adccntl->nv)+(8*adccntl->nm));
	adccntl->numberOfChunks=0;
	adccntl->fromParent=fromParent;
	adccntl->nViewRows=0;
	if (fromParent)
	{
		adccntl->nd=adccntl->smallestParentLevel;
		fseek(adccntl->viewFile, adccntl->viewOffset, 0);
		;
		adccntl->nRowsToRead=adccntl->nParentViewRows;
	}
	else
	{
		adccntl->nd=adccntl->nTopDims;
		adccntl->nRowsToRead=adccntl->nInputRecs;
	}
	adccntl->inpRecSize=((4*adccntl->nd)+(8*adccntl->nm));
	adccntl->outRecSize=((4*adccntl->nv)+(8*adccntl->nm));
}

int32 CloseAdcView(ADC_VIEW_CNTL * adccntl)
{
	if (adccntl->inpf)
	{
		fclose(adccntl->inpf);
	}
	if (adccntl->viewFile)
	{
		fclose(adccntl->viewFile);
	}
	if (adccntl->fileOfChunks)
	{
		fclose(adccntl->fileOfChunks);
	}
	if (adccntl->groupbyFile)
	{
		fclose(adccntl->groupbyFile);
	}
	if (adccntl->adcViewSizesFile)
	{
		fclose(adccntl->adcViewSizesFile);
	}
	if (adccntl->viewSizesFile)
	{
		fclose(adccntl->viewSizesFile);
	}
	if (DeleteOneFile(adccntl->chunksFileName))
	{
		return 6;
	}
	if (DeleteOneFile(adccntl->viewSizesFileName))
	{
		return 6;
	}
	if (DeleteOneFile(adccntl->groupbyFileName))
	{
		return 6;
	}
	if (adccntl->chunksParams)
	{
		free(adccntl->chunksParams);
		adccntl->chunksParams=((void * )0);
	}
	if (adccntl->memPool)
	{
		free(adccntl->memPool);
		adccntl->memPool=((void * )0);
	}
	if (adccntl->jpp)
	{
		free(adccntl->jpp);
		adccntl->jpp=((void * )0);
	}
	if (adccntl->lpp)
	{
		free(adccntl->lpp);
		adccntl->lpp=((void * )0);
	}
	if (adccntl->logf)
	{
		fclose(adccntl->logf);
	}
	free(adccntl);
	return 0;
}

void AdcCntlLog(ADC_VIEW_CNTL * adccntlp)
{
	fprintf(adccntlp->logf, "    memoryLimit = %20d\n", adccntlp->memoryLimit);
	fprintf(adccntlp->logf, "    treeNodeSize = %20d\n", adccntlp->tree->treeNodeSize);
	fprintf(adccntlp->logf, " treeMemoryLimit = %20d\n", adccntlp->tree->memoryLimit);
	fprintf(adccntlp->logf, "    nNodesLimit = %20d\n", adccntlp->tree->nNodesLimit);
	fprintf(adccntlp->logf, "freeNodeCounter = %20d\n", adccntlp->tree->freeNodeCounter);
	fprintf(adccntlp->logf, "	nViewRows = %20d\n", adccntlp->nViewRows);
}

int32 ViewSizesVerification(ADC_VIEW_CNTL * adccntlp)
{
	char inps[1024];
	char msg[64];
	uint32 * viewCounts;
	uint32 selection_viewSize[2];
	uint32 sz;
	uint32 sel[64];
	uint32 i;
	uint32 k;
	uint64 tx;
	uint32 iTx;
	viewCounts=((uint32 * )( & adccntlp->memPool[0]));
	#pragma loop name ViewSizesVerification#0 
	#pragma cetus parallel 
	#pragma omp parallel for
	for (i=0; i<=adccntlp->nViewLimit; i ++ )
	{
		viewCounts[i]=0;
	}
	fseek(adccntlp->viewSizesFile, 0, 0);
	;
	fseek(adccntlp->adcViewSizesFile, 0, 0);
	;
	while (fread(selection_viewSize, 8, 1, adccntlp->viewSizesFile))
	{
		viewCounts[selection_viewSize[0]]=selection_viewSize[1];
	}
	k=0;
	while (fscanf(adccntlp->adcViewSizesFile, "%s", inps)!=( - 1))
	{
		if (strcmp(inps, "Selection:")==0)
		{
			while (fscanf(adccntlp->adcViewSizesFile, "%s", inps))
			{
				if (strcmp(inps, "View")==0)
				{
					break;
				}
				sel[k ++ ]=atoi(inps);
			}
		}
		if (strcmp(inps, "Size:")==0)
		{
			fscanf(adccntlp->adcViewSizesFile, "%s", inps);
			sz=atoi(inps);
			CreateBinTuple( & tx, sel, k);
			iTx=((int32)(tx>>(64-adccntlp->nTopDims)));
			adccntlp->verificationFailed=0;
			if ( ! adccntlp->numberOfMadeViews)
			{
				adccntlp->verificationFailed=1;
			}
			if (viewCounts[iTx]!=0)
			{
				if (viewCounts[iTx]!=sz)
				{
					if (viewCounts[iTx]!=adccntlp->nInputRecs)
					{
						fprintf(adccntlp->logf, "A view size is wrong: genSz=%d calcSz=%d\n", sz, viewCounts[iTx]);
						adccntlp->verificationFailed=1;
						return 7;
					}
				}
			}
			k=0;
		}
	}
	/* of while() */
	fprintf(adccntlp->logf, "\n\nMeaning of the log file colums is as follows:\n");
	fprintf(adccntlp->logf, "Row Number | Groupby | View Size | Measure Sums | Number of Chunks\n");
	if ( ! adccntlp->verificationFailed)
	{
		strcpy(msg, "Verification=passed");
	}
	else
	{
		strcpy(msg, "Verification=failed");
	}
	fseek(adccntlp->logf, 0, 0);
	;
	fprintf(adccntlp->logf, msg);
	fseek(adccntlp->logf, 0, 2);
	;
	fseek(adccntlp->viewSizesFile, 0, 0);
	;
	return 0;
}

int32 ComputeGivenGroupbys(ADC_VIEW_CNTL * adccntlp)
{
	int32 retCode;
	uint32 i;
	uint64 binRepTuple;
	uint32 ut32;
	uint32 nViews = 0;
	uint32 nSelectedDims;
	uint32 smp;
	uint32 firstView = 1;
	uint32 selection_viewsize[2];
	char ttout[16];
	while (fread( & binRepTuple, 8, 1, adccntlp->groupbyFile))
	{
		#pragma loop name ComputeGivenGroupbys#0 
		#pragma cetus parallel 
		#pragma omp parallel for
		for (i=0; i<adccntlp->nm; i ++ )
		{
			adccntlp->checksums[i]=0;
		}
		nViews ++ ;
		swap8( & binRepTuple);
		GetRegTupleFromBin64(binRepTuple, adccntlp->selection, adccntlp->nTopDims,  & nSelectedDims);
		ut32=((uint32)(binRepTuple>>(64-adccntlp->nTopDims)));
		selection_viewsize[0]=ut32;
		ut32<<=(32-adccntlp->nTopDims);
		adccntlp->groupby=ut32;
		if (firstView)
		{
			firstView=0;
			if (ReadWholeInputData(adccntlp, adccntlp->inpf))
			{
				fprintf(stderr, "ReadWholeInputData failed.\n");
				return 2;
			}
		}
		smp=noneParent;
		if (smp!=noneParent)
		{
			GetRegTupleFromParent(binRepTuple, adccntlp->parBinRepTuple, adccntlp->selection, adccntlp->nTopDims);
		}
		InitAdcViewCntl(adccntlp, nSelectedDims, adccntlp->selection, ((smp==noneParent) ? 0 : 1));
		if (retCode=ComputeMemoryFittedView(adccntlp))
		{
			fprintf(stderr, "ComputeMemoryFittedView failed.\n");
			return retCode;
		}
		#pragma loop name ComputeGivenGroupbys#1 
		#pragma cetus parallel 
		#pragma omp parallel for
		for (i=0; i<adccntlp->nm; i ++ )
		{
			adccntlp->totchs[i]+=adccntlp->checksums[i];
		}
		selection_viewsize[1]=adccntlp->nViewRows;
		fwrite(selection_viewsize, 8, 1, adccntlp->viewSizesFile);
		adccntlp->totalViewFileSize+=(adccntlp->outRecSize*adccntlp->nViewRows);
		sprintf(ttout, "%7d ", nViews);
		WriteOne32Tuple(ttout, adccntlp->groupby, adccntlp->nTopDims, adccntlp->logf);
		fprintf(adccntlp->logf, " |  %15d | ", adccntlp->nViewRows);
		#pragma loop name ComputeGivenGroupbys#2 
		for (i=0; i<adccntlp->nm; i ++ )
		{
			fprintf(adccntlp->logf, " %20lld", adccntlp->checksums[i]);
		}
		fprintf(adccntlp->logf, " | %5d", adccntlp->numberOfChunks);
	}
	adccntlp->numberOfMadeViews=nViews;
	if (ViewSizesVerification(adccntlp))
	{
		return 7;
	}
	return 0;
}
