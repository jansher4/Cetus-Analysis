/*
Copyright (C) 1991-2016 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it andor
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <http:www.gnu.org/licenses/>. 
*/
/*
This header is separate from features.h so that the compiler can
   include it implicitly at the start of every compilation.  It must
   not itself include <features.h> or any other header that includes
   <features.h> because the implicit include comes before any feature
   test macros that may be defined in a source file before it first
   explicitly includes a system header.  GCC knows the name of this
   header in order to preinclude it. 
*/
/*
glibc's intent is to support the IEC 559 math functionality, real
   and complex.  If the GCC (4.9 and later) predefined macros
   specifying compiler intent are available, use them to determine
   whether the overall intent is to support these features; otherwise,
   presume an older compiler has intent to support these features and
   define these macros by default. 
*/
/*
wchar_t uses Unicode 8.0.0.  Version 8.0 of the Unicode Standard is
   synchronized with ISOIEC 10646:2014, plus Amendment 1 (published
   2015-05-15). 
*/
/* We do not support C11 <threads.h>.  */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "adc.h"
#include "macrodef.h"
int32 KeyComp(const uint32 * a, const uint32 * b, uint32 n)
{
	uint32 i;
	#pragma loop name KeyComp#0 
	for (i=0; i<n; i ++ )
	{
		if (a[i]<b[i])
		{
			return ( - 1);
		}
		else
		{
			if (a[i]>b[i])
			{
				return 1;
			}
		}
	}
	return 0;
}

int32 TreeInsert(RBTree * tree, uint32 * attrs)
{
	uint32 sl = 1;
	uint32 * attrsP;
	int32 cmpres;
	treeNode * xNd, * yNd, * tmp;
	tmp=( & tree->root);
	xNd=tmp->left;
	if (xNd==((void * )0))
	{
		tree->count ++ ;
		tree->mp=((struct treeNode * )(tree->memPool+tree->memaddr));
		tree->memaddr+=tree->treeNodeSize;
		tree->freeNodeCounter -- ;
		if (tree->freeNodeCounter==0)
		{
			tree->memoryIsFull=1;
		}
		xNd=(tmp->left=tree->mp);
		memcpy( & xNd->nodeMemPool[0],  & attrs[0], tree->nodeDataSize);
		xNd->left=(xNd->right=((void * )0));
		xNd->clr=BLACK;
		return 0;
	}
	tree->drcts[0]=0;
	tree->nodes[0]=( & tree->root);
	while (1)
	{
		attrsP=((uint32 * )( & xNd->nodeMemPool[tree->nm]));
		cmpres=KeyComp( & attrs[tree->nm<<1], attrsP, tree->nd);
		if (cmpres<0)
		{
			tree->nodes[sl]=xNd;
			tree->drcts[sl ++ ]=0;
			yNd=xNd->left;
			if (yNd==((void * )0))
			{
				tree->mp=((struct treeNode * )(tree->memPool+tree->memaddr));
				tree->memaddr+=tree->treeNodeSize;
				tree->freeNodeCounter -- ;
				if (tree->freeNodeCounter==0)
				{
					tree->memoryIsFull=1;
				}
				xNd=(xNd->left=tree->mp);
				break;
			}
		}
		else
		{
			if (cmpres>0)
			{
				tree->nodes[sl]=xNd;
				tree->drcts[sl ++ ]=1;
				yNd=xNd->right;
				if (yNd==((void * )0))
				{
					tree->mp=((struct treeNode * )(tree->memPool+tree->memaddr));
					tree->memaddr+=tree->treeNodeSize;
					tree->freeNodeCounter -- ;
					if (tree->freeNodeCounter==0)
					{
						tree->memoryIsFull=1;
					}
					xNd=(xNd->right=tree->mp);
					break;
				}
			}
			else
			{
				uint64 ii;
				int64 * mx;
				mx=((int64 * )( & attrs[0]));
				#pragma loop name TreeInsert#0 
				#pragma cetus parallel 
				#pragma omp parallel for
				for (ii=0; ii<tree->nm; ii ++ )
				{
					xNd->nodeMemPool[ii]+=mx[ii];
				}
				return 0;
			}
		}
		xNd=yNd;
	}
	tree->count ++ ;
	memcpy( & xNd->nodeMemPool[0],  & attrs[0], tree->nodeDataSize);
	xNd->left=(xNd->right=((void * )0));
	xNd->clr=RED;
	while (1)
	{
		if ((tree->nodes[sl-1]->clr!=RED)||(sl<3))
		{
			break;
		}
		if (tree->drcts[sl-2]==0)
		{
			yNd=tree->nodes[sl-2]->right;
			if ((yNd!=((void * )0))&&(yNd->clr==RED))
			{
				tree->nodes[sl-1]->clr=BLACK;
				yNd->clr=BLACK;
				tree->nodes[sl-2]->clr=RED;
				sl-=2;
			}
			else
			{
				if (tree->drcts[sl-1]==1)
				{
					xNd=tree->nodes[sl-1];
					yNd=xNd->right;
					xNd->right=yNd->left;
					yNd->left=xNd;
					tree->nodes[sl-2]->left=yNd;
				}
				else
				{
					yNd=tree->nodes[sl-1];
				}
				xNd=tree->nodes[sl-2];
				xNd->clr=RED;
				yNd->clr=BLACK;
				xNd->left=yNd->right;
				yNd->right=xNd;
				if (tree->drcts[sl-3])
				{
					tree->nodes[sl-3]->right=yNd;
				}
				else
				{
					tree->nodes[sl-3]->left=yNd;
				}
				break;
			}
		}
		else
		{
			yNd=tree->nodes[sl-2]->left;
			if ((yNd!=((void * )0))&&(yNd->clr==RED))
			{
				tree->nodes[sl-1]->clr=BLACK;
				yNd->clr=BLACK;
				tree->nodes[sl-2]->clr=RED;
				sl-=2;
			}
			else
			{
				if (tree->drcts[sl-1]==0)
				{
					xNd=tree->nodes[sl-1];
					yNd=xNd->left;
					xNd->left=yNd->right;
					yNd->right=xNd;
					tree->nodes[sl-2]->right=yNd;
				}
				else
				{
					yNd=tree->nodes[sl-1];
				}
				xNd=tree->nodes[sl-2];
				xNd->clr=RED;
				yNd->clr=BLACK;
				xNd->right=yNd->left;
				yNd->left=xNd;
				if (tree->drcts[sl-3])
				{
					tree->nodes[sl-3]->right=yNd;
				}
				else
				{
					tree->nodes[sl-3]->left=yNd;
				}
				break;
			}
		}
	}
	tree->root.left->clr=BLACK;
	return 0;
}

int32 WriteViewToDisk(ADC_VIEW_CNTL * avp, treeNode * t)
{
	uint32 i;
	if ( ! t)
	{
		return 0;
	}
	if (WriteViewToDisk(avp, t->left))
	{
		return 1;
	}
	#pragma loop name WriteViewToDisk#0 
	#pragma cetus parallel 
	#pragma omp parallel for
	for (i=0; i<avp->nm; i ++ )
	{
		avp->mSums[i]+=t->nodeMemPool[i];
	}
	if (fwrite(t->nodeMemPool, avp->outRecSize, 1, avp->viewFile)!=1)
	{
		fprintf(stderr, "\n Write error from WriteToFile()\n");
		return 1;
	}
	;
	if (WriteViewToDisk(avp, t->right))
	{
		return 1;
	}
	return 0;
}

int32 WriteViewToDiskCS(ADC_VIEW_CNTL * avp, treeNode * t, uint64 * ordern)
{
	uint32 i;
	if ( ! t)
	{
		return 0;
	}
	if (WriteViewToDiskCS(avp, t->left, ordern))
	{
		return 1;
	}
	#pragma loop name WriteViewToDiskCS#0 
	for (i=0; i<avp->nm; i ++ )
	{
		avp->mSums[i]+=t->nodeMemPool[i];
		avp->checksums[i]+=((( ++ ( * ordern))*t->nodeMemPool[i])%measbound);
	}
	if (fwrite(t->nodeMemPool, avp->outRecSize, 1, avp->viewFile)!=1)
	{
		fprintf(stderr, "\n Write error from WriteToFile()\n");
		return 1;
	}
	;
	if (WriteViewToDiskCS(avp, t->right, ordern))
	{
		return 1;
	}
	return 0;
}

int32 computeChecksum(ADC_VIEW_CNTL * avp, treeNode * t, uint64 * ordern)
{
	uint32 i;
	if ( ! t)
	{
		return 0;
	}
	if (computeChecksum(avp, t->left, ordern))
	{
		return 1;
	}
	#pragma loop name computeChecksum#0 
	for (i=0; i<avp->nm; i ++ )
	{
		avp->checksums[i]+=((( ++ ( * ordern))*t->nodeMemPool[i])%measbound);
	}
	if (computeChecksum(avp, t->right, ordern))
	{
		return 1;
	}
	return 0;
}

int32 WriteChunkToDisk(uint32 recordSize, FILE * fileOfChunks, treeNode * t, FILE * logFile)
{
	if ( ! t)
	{
		return 0;
	}
	if (WriteChunkToDisk(recordSize, fileOfChunks, t->left, logFile))
	{
		return 1;
	}
	if (fwrite(t->nodeMemPool, recordSize, 1, fileOfChunks)!=1)
	{
		fprintf(stderr, "\n Write error from WriteToFile()\n");
		return 1;
	}
	;
	if (WriteChunkToDisk(recordSize, fileOfChunks, t->right, logFile))
	{
		return 1;
	}
	return 0;
}

RBTree *CreateEmptyTree(uint32 nd, uint32 nm, uint32 memoryLimit, unsigned char * memPool)
{
	RBTree * tree = (RBTree * )malloc(sizeof (RBTree));
	if ( ! tree)
	{
		return ((void * )0);
	}
	tree->root.left=((void * )0);
	tree->root.right=((void * )0);
	tree->count=0;
	tree->memaddr=0;
	tree->treeNodeSize=((sizeof (struct treeNode)+(4*(nd-1)))+(8*nm));
	if ((tree->treeNodeSize%8)!=0)
	{
		tree->treeNodeSize+=4;
	}
	tree->memoryLimit=memoryLimit;
	tree->memoryIsFull=0;
	tree->nodeDataSize=((4*nd)+(8*nm));
	tree->mp=((void * )0);
	tree->nNodesLimit=(tree->memoryLimit/tree->treeNodeSize);
	tree->freeNodeCounter=tree->nNodesLimit;
	tree->nd=nd;
	tree->nm=nm;
	tree->memPool=memPool;
	tree->nodes=((treeNode * * )malloc(sizeof (treeNode * )*64));
	if ( ! tree->nodes)
	{
		return ((void * )0);
	}
	tree->drcts=((uint32 * )malloc(sizeof (uint32)*64));
	if ( ! tree->drcts)
	{
		return ((void * )0);
	}
	return tree;
}

void InitializeTree(RBTree * tree, uint32 nd, uint32 nm)
{
	tree->root.left=((void * )0);
	tree->root.right=((void * )0);
	tree->count=0;
	tree->memaddr=0;
	tree->treeNodeSize=((sizeof (struct treeNode)+(4*(nd-1)))+(8*nm));
	if ((tree->treeNodeSize%8)!=0)
	{
		tree->treeNodeSize+=4;
	}
	tree->memoryIsFull=0;
	tree->nodeDataSize=((4*nd)+(8*nm));
	tree->mp=((void * )0);
	tree->nNodesLimit=(tree->memoryLimit/tree->treeNodeSize);
	tree->freeNodeCounter=tree->nNodesLimit;
	tree->nd=nd;
	tree->nm=nm;
}

int32 DestroyTree(RBTree * tree)
{
	if (tree==((void * )0))
	{
		return 3;
	}
	if (tree->memPool!=((void * )0))
	{
		free(tree->memPool);
	}
	if (tree->nodes)
	{
		free(tree->nodes);
	}
	if (tree->drcts)
	{
		free(tree->drcts);
	}
	free(tree);
	return 0;
}
