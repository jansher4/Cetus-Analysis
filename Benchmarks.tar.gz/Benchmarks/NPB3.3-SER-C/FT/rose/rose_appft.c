//-------------------------------------------------------------------------//
//                                                                         //
//  This benchmark is a serial C version of the NPB FT code. This C        //
//  version is developed by the Center for Manycore Programming at Seoul   //
//  National University and derived from the serial Fortran versions in    //
//  "NPB3.3-SER" developed by NAS.                                         //
//                                                                         //
//  Permission to use, copy, distribute and modify this software for any   //
//  purpose with or without fee is hereby granted. This software is        //
//  provided "as is" without express or implied warranty.                  //
//                                                                         //
//  Information on NPB 3.3, including the technical report, the original   //
//  specifications, source code, results and information on how to submit  //
//  new results, is available at:                                          //
//                                                                         //
//           http://www.nas.nasa.gov/Software/NPB/                         //
//                                                                         //
//  Send comments or suggestions for this C version to cmp@aces.snu.ac.kr  //
//                                                                         //
//          Center for Manycore Programming                                //
//          School of Computer Science and Engineering                     //
//          Seoul National University                                      //
//          Seoul 151-744, Korea                                           //
//                                                                         //
//          E-mail:  cmp@aces.snu.ac.kr                                    //
//                                                                         //
//-------------------------------------------------------------------------//
//-------------------------------------------------------------------------//
// Authors: Sangmin Seo, Jungwon Kim, Jun Lee, Jeongho Nah, Gangwon Jo,    //
//          and Jaejin Lee                                                 //
//-------------------------------------------------------------------------//
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "global.h"
#include "../common/timers.h"
// for checksum data
/* common /sumcomm/ */
static dcomplex sums[7];
/* common /mainarrays/ */
static double twiddle[128][256][257];
static dcomplex xnt[128][256][257];
static dcomplex y[128][256][257];
//static dcomplex pad1[128], pad2[128];

void appft(int niter,double *total_time,logical *verified)
{
  int i;
  int j;
  int k;
  int kt;
  int n12;
  int n22;
  int n32;
  int ii;
  int jj;
  int kk;
  int ii2;
  int ik2;
  double ap;
  dcomplex exp1[256];
  dcomplex exp2[256];
  dcomplex exp3[128];
  for (i = 1; i <= 15; i += 1) {
    timer_clear(i);
  }
  timer_start(2);
  compute_initial_conditions(256,256,128,xnt);
  CompExp(256,exp1);
  CompExp(256,exp2);
  CompExp(128,exp3);
  fftXYZ(1,256,256,128,xnt,(dcomplex *)y,exp1,exp2,exp3);
  timer_stop(2);
  timer_start(1);
  if (timers_enabled) 
    timer_start(13);
  n12 = 256 / 2;
  n22 = 256 / 2;
  n32 = 128 / 2;
  ap = - 4.0 * 1.0e-6 * (3.141592653589793238 * 3.141592653589793238);
  for (i = 0; i <= 127; i += 1) {
    ii = i - i / n32 * 128;
    ii2 = ii * ii;
    for (k = 0; k <= 255; k += 1) {
      kk = k - k / n22 * 256;
      ik2 = ii2 + kk * kk;
      for (j = 0; j <= 255; j += 1) {
        jj = j - j / n12 * 256;
        twiddle[i][k][j] = exp(ap * ((double )(jj * jj + ik2)));
      }
    }
  }
  if (timers_enabled) 
    timer_stop(13);
  if (timers_enabled) 
    timer_start(12);
  compute_initial_conditions(256,256,128,xnt);
  if (timers_enabled) 
    timer_stop(12);
  if (timers_enabled) 
    timer_start(15);
  fftXYZ(1,256,256,128,xnt,(dcomplex *)y,exp1,exp2,exp3);
  if (timers_enabled) 
    timer_stop(15);
  for (kt = 1; kt <= niter; kt += 1) {
    if (timers_enabled) 
      timer_start(11);
    evolve(256,256,128,xnt,y,twiddle);
    if (timers_enabled) 
      timer_stop(11);
    if (timers_enabled) 
      timer_start(15);
    fftXYZ(- 1,256,256,128,xnt,(dcomplex *)xnt,exp1,exp2,exp3);
    if (timers_enabled) 
      timer_stop(15);
    if (timers_enabled) 
      timer_start(10);
    CalculateChecksum(&sums[kt],kt,256,256,128,xnt);
    if (timers_enabled) 
      timer_stop(10);
  }
// Verification test.
  if (timers_enabled) 
    timer_start(14);
  verify(256,256,128,niter,sums,verified);
  if (timers_enabled) 
    timer_stop(14);
  timer_stop(1);
   *total_time = timer_read(1);
  if (!timers_enabled) 
    return ;
  printf(" FT subroutine timers \n");
  printf(" %26s =%9.4f\n","FT total                  ",(timer_read(1)));
  printf(" %26s =%9.4f\n","WarmUp time               ",(timer_read(2)));
  printf(" %26s =%9.4f\n","fftXYZ body               ",(timer_read(3)));
  printf(" %26s =%9.4f\n","Swarztrauber              ",(timer_read(4)));
  printf(" %26s =%9.4f\n","X time                    ",(timer_read(7)));
  printf(" %26s =%9.4f\n","Y time                    ",(timer_read(8)));
  printf(" %26s =%9.4f\n","Z time                    ",(timer_read(9)));
  printf(" %26s =%9.4f\n","CalculateChecksum         ",(timer_read(10)));
  printf(" %26s =%9.4f\n","evolve                    ",(timer_read(11)));
  printf(" %26s =%9.4f\n","compute_initial_conditions",(timer_read(12)));
  printf(" %26s =%9.4f\n","twiddle                   ",(timer_read(13)));
  printf(" %26s =%9.4f\n","verify                    ",(timer_read(14)));
  printf(" %26s =%9.4f\n","fftXYZ                    ",(timer_read(15)));
  printf(" %26s =%9.4f\n","Benchmark time            ", *total_time);
}
