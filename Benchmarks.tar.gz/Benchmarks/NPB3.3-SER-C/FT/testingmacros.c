#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include<omp.h>
#define ub 55999000
int main(){
/*
#define ADD(x, y) (x + y)

#define MULT(x, y) (x * y)

#define ADDMUL(x,y) ADD(ADD(x,y),MULT(x,y))
#define MULTDIVIDE(x,y) ADDMUL(x,y)/MULT(x,y)
//MULT(3,4);
printf("Output %d\n", MULT(ADD(4,6),4));
printf("Output %d\n", ADDMUL(4,6));
printf("Output %d\n", MULTDIVIDE(MULT(ADD(4,6),4),ADDMUL(4,6)));
*/
#define dcmplx(r,i)       (dcomplex){r, i}
#define dcmplx_add(a,b)   (dcomplex){(a).real+(b).real, (a).imag+(b).imag}
#define dcmplx_sub(a,b)   (dcomplex){(a).real-(b).real, (a).imag-(b).imag}
#define dcmplx_mul(a,b)   (dcomplex){((a).real*(b).real)-((a).imag*(b).imag),\
                                     ((a).real*(b).imag)+((a).imag*(b).real)}
#define dcmplx_mul2(a,b)  (dcomplex){(a).real*(b), (a).imag*(b)}

return 0;
}

