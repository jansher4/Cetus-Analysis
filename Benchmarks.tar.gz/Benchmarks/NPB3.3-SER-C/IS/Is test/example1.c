// A test case of a non-canonical loop.
// Naively putting openmp parallel for for it is wrong.
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include<omp.h>

static int a[531000000], b[531000000];
//#define j = 10
//#define k = 10
int j = 10;
int k = 10;
int main()
{
    printf("\nk = %d\n\n",'k');
    printf("\nj = %d\n\n",'j');
 if('j' != 'j'){
	printf("\nHello\n\n\n");
	} else
printf("\nNO\n\n");
 return 0;
}

///*
///*

/*
int main()
{
  int i,j;
  int limit =531000000;
double ctime1 = omp_get_wtime();
#pragma omp parallel for private (i) num_threads(4)
  for (i = 0; i < limit ; i++ )
  {
	//j = i; 
    b[i]=a[i];
  }
	double ctime2 = omp_get_wtime();
	printf("\nCtimeSec  %f\n\n", ctime2 - ctime1);
  return 0;
}
*/








