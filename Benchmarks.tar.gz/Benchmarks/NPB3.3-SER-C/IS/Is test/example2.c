// A test case of a non-canonical loop.
// Naively putting openmp parallel for for it is wrong.
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include<omp.h>




int main()
{
int i, j = 10, sum=0;
  int limit =531000000;
double ctime1 = omp_get_wtime();
static int test_index_array[531000000], A_test_index_array[531000000], test_rank_array[531000000] ,A_test_rank_array[531000000];


//#pragma omp parallel for private (i) firstprivate (limit)
	for (i = 0;i<limit; i++) {
    switch('A'){
      case 'S':
      //test_index_array[i] = S_test_index_array[i];
      test_rank_array[i] = A_test_rank_array[i]+((1+limit)-i);
      break; 
      case 'A':
      //test_index_array[i] = A_test_index_array[i];
      test_rank_array[i] = A_test_rank_array[i]+(limit-i);
      break; 
      case 'W':
      //test_index_array[i] = W_test_index_array[i];
      test_rank_array[i] = A_test_rank_array[i]+((1-limit)-i);
      break; 
      case 'B':
     // test_index_array[i] = B_test_index_array[i];
      test_rank_array[i] = A_test_rank_array[i]+((2-limit)-i);
      break; 
      case 'C':
      //test_index_array[i] = C_test_index_array[i];
      test_rank_array[i] = A_test_rank_array[i]+((2+limit)-i);
      break; 
      case 'D':
      //test_index_array[i] = D_test_index_array[i];
      test_rank_array[i] = A_test_rank_array[i]+((3+limit)-i);
      break; 
    }
  }


	double ctime2 = omp_get_wtime();
	printf("\nCtimeSec  %f\n\n", ctime2 - ctime1);
printf("Value[%d]=%d",40,test_rank_array[40]);
printf("\nValue[%d]=%d",50,test_rank_array[50]);
printf("\nValue[%d]=%d",90,test_rank_array[90]);
  return 0;
}


     







