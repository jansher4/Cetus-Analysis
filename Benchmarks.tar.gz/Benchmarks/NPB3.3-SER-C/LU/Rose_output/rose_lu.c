//-------------------------------------------------------------------------//
//                                                                         //
//  This benchmark is a serial C version of the NPB LU code. This C        //
//  version is developed by the Center for Manycore Programming at Seoul   //
//  National University and derived from the serial Fortran versions in    //
//  "NPB3.3-SER" developed by NAS.                                         //
//                                                                         //
//  Permission to use, copy, distribute and modify this software for any   //
//  purpose with or without fee is hereby granted. This software is        //
//  provided "as is" without express or implied warranty.                  //
//                                                                         //
//  Information on NPB 3.3, including the technical report, the original   //
//  specifications, source code, results and information on how to submit  //
//  new results, is available at:                                          //
//                                                                         //
//           http://www.nas.nasa.gov/Software/NPB/                         //
//                                                                         //
//  Send comments or suggestions for this C version to cmp@aces.snu.ac.kr  //
//                                                                         //
//          Center for Manycore Programming                                //
//          School of Computer Science and Engineering                     //
//          Seoul National University                                      //
//          Seoul 151-744, Korea                                           //
//                                                                         //
//          E-mail:  cmp@aces.snu.ac.kr                                    //
//                                                                         //
//-------------------------------------------------------------------------//
//-------------------------------------------------------------------------//
// Authors: Sangmin Seo, Jungwon Kim, Jun Lee, Jeongho Nah, Gangwon Jo,    //
//          and Jaejin Lee                                                 //
//-------------------------------------------------------------------------//
//---------------------------------------------------------------------
//   program applu
//---------------------------------------------------------------------
//---------------------------------------------------------------------
//
//   driver for the performance evaluation of the solver for
//   five coupled parabolic/elliptic partial differential equations.
//
//---------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "applu.incl"
#include "../common/timers.h"
#include "../common/print_results.h"
//---------------------------------------------------------------------
// grid
//---------------------------------------------------------------------
/* common/cgcon/ */
double dxi;
double deta;
double dzeta;
double tx1;
double tx2;
double tx3;
double ty1;
double ty2;
double ty3;
double tz1;
double tz2;
double tz3;
int nx;
int ny;
int nz;
int nx0;
int ny0;
int nz0;
int ist;
int iend;
int jst;
int jend;
int ii1;
int ii2;
int ji1;
int ji2;
int ki1;
int ki2;
//---------------------------------------------------------------------
// dissipation
//---------------------------------------------------------------------
/* common/disp/ */
double dx1;
double dx2;
double dx3;
double dx4;
double dx5;
double dy1;
double dy2;
double dy3;
double dy4;
double dy5;
double dz1;
double dz2;
double dz3;
double dz4;
double dz5;
double dssp;
//---------------------------------------------------------------------
// field variables and residuals
// to improve cache performance, second two dimensions padded by 1 
// for even number sizes only.
// Note: corresponding array (called "v") in routines blts, buts, 
// and l2norm are similarly padded
//---------------------------------------------------------------------
/* common/cvar/ */
double u[64][65][65][5];
double rsd[64][65][65][5];
double frct[64][65][65][5];
double flux[64][5];
double qs[64][65][65];
double rho_i[64][65][65];
//---------------------------------------------------------------------
// output control parameters
//---------------------------------------------------------------------
/* common/cprcon/ */
int ipr;
int inorm;
//---------------------------------------------------------------------
// newton-raphson iteration control parameters
//---------------------------------------------------------------------
/* common/ctscon/ */
double dt;
double omega;
double tolrsd[5];
double rsdnm[5];
double errnm[5];
double frc;
double ttotal;
int itmax;
int invert;
/* common/cjac/ */
double a[64][65][5][5];
double b[64][65][5][5];
double c[64][65][5][5];
double d[64][65][5][5];
//---------------------------------------------------------------------
// coefficients of the exact solution
//---------------------------------------------------------------------
/* common/cexact/ */
double ce[5][13];
//---------------------------------------------------------------------
// timers
//---------------------------------------------------------------------
/* common/timer/ */
double maxtime;
logical timeron;

int main(int argc,char *argv[])
{
  char Class;
  logical verified;
  double mflops;
  double t;
  double tmax;
  double trecs[12];
  int i;
  char *t_names[12];
//---------------------------------------------------------------------
// Setup info for timers
//---------------------------------------------------------------------
  FILE *fp;
  if ((fp = fopen("timer.flag","r")) != ((void *)0)) {
    timeron = true;
    t_names[1] = "total";
    t_names[2] = "rhsx";
    t_names[3] = "rhsy";
    t_names[4] = "rhsz";
    t_names[5] = "rhs";
    t_names[6] = "jacld";
    t_names[7] = "blts";
    t_names[8] = "jacu";
    t_names[9] = "buts";
    t_names[10] = "add";
    t_names[11] = "l2norm";
    fclose(fp);
  }
   else {
    timeron = false;
  }
//---------------------------------------------------------------------
// read input data
//---------------------------------------------------------------------
  read_input();
//---------------------------------------------------------------------
// set up domain sizes
//---------------------------------------------------------------------
  domain();
//---------------------------------------------------------------------
// set up coefficients
//---------------------------------------------------------------------
  setcoeff();
//---------------------------------------------------------------------
// set the boundary values for dependent variables
//---------------------------------------------------------------------
  setbv();
//---------------------------------------------------------------------
// set the initial values for dependent variables
//---------------------------------------------------------------------
  setiv();
//---------------------------------------------------------------------
// compute the forcing term based on prescribed exact solution
//---------------------------------------------------------------------
  erhs();
//---------------------------------------------------------------------
// perform one SSOR iteration to touch all pages
//---------------------------------------------------------------------
  ssor(1);
//---------------------------------------------------------------------
// reset the boundary and initial values
//---------------------------------------------------------------------
  setbv();
  setiv();
//---------------------------------------------------------------------
// perform the SSOR iterations
//---------------------------------------------------------------------
  ssor(itmax);
//---------------------------------------------------------------------
// compute the solution error
//---------------------------------------------------------------------
  error();
//---------------------------------------------------------------------
// compute the surface integral
//---------------------------------------------------------------------
  pintgr();
//---------------------------------------------------------------------
// verification test
//---------------------------------------------------------------------
  verify(rsdnm,errnm,frc,&Class,&verified);
  mflops = ((double )itmax) * (1984.77 * ((double )nx0) * ((double )ny0) * ((double )nz0) - 10923.3 * pow(((double )(nx0 + ny0 + nz0)) / 3.0,2.0) + 27770.9 * ((double )(nx0 + ny0 + nz0)) / 3.0 - 144010.0) / (maxtime * 1000000.0);
  print_results("LU",Class,nx0,ny0,nz0,itmax,maxtime,mflops,"          floating point",verified,"3.3.1","26 Apr 2020","gcc","$(CC)","-lm","-I../common","-g -Wall -O3 -fopenmp -mcmodel=medium","-O3 -fopenmp -mcmodel=medium","(none)");
//---------------------------------------------------------------------
// More timers
//---------------------------------------------------------------------
  if (timeron) {
    for (i = 1; i <= 11; i += 1) {
      trecs[i] = timer_read(i);
    }
    tmax = maxtime;
    if (tmax == 0.0) 
      tmax = 1.0;
    printf("  SECTION     Time (secs)\n");
    for (i = 1; i <= 11; i += 1) {
      printf("  %-8s:%9.3f  (%6.2f%%)\n",t_names[i],trecs[i],trecs[i] * 100. / tmax);
      if (i == 5) {
        t = trecs[2] + trecs[3] + trecs[4];
        printf("     --> %8s:%9.3f  (%6.2f%%)\n","sub-rhs",t,t * 100. / tmax);
        t = trecs[i] - t;
        printf("     --> %8s:%9.3f  (%6.2f%%)\n","rest-rhs",t,t * 100. / tmax);
      }
    }
  }
  return 0;
}
