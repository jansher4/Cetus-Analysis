//-------------------------------------------------------------------------//
//                                                                         //
//  This benchmark is a serial C version of the NPB LU code. This C        //
//  version is developed by the Center for Manycore Programming at Seoul   //
//  National University and derived from the serial Fortran versions in    //
//  "NPB3.3-SER" developed by NAS.                                         //
//                                                                         //
//  Permission to use, copy, distribute and modify this software for any   //
//  purpose with or without fee is hereby granted. This software is        //
//  provided "as is" without express or implied warranty.                  //
//                                                                         //
//  Information on NPB 3.3, including the technical report, the original   //
//  specifications, source code, results and information on how to submit  //
//  new results, is available at:                                          //
//                                                                         //
//           http://www.nas.nasa.gov/Software/NPB/                         //
//                                                                         //
//  Send comments or suggestions for this C version to cmp@aces.snu.ac.kr  //
//                                                                         //
//          Center for Manycore Programming                                //
//          School of Computer Science and Engineering                     //
//          Seoul National University                                      //
//          Seoul 151-744, Korea                                           //
//                                                                         //
//          E-mail:  cmp@aces.snu.ac.kr                                    //
//                                                                         //
//-------------------------------------------------------------------------//
//-------------------------------------------------------------------------//
// Authors: Sangmin Seo, Jungwon Kim, Jun Lee, Jeongho Nah, Gangwon Jo,    //
//          and Jaejin Lee                                                 //
//-------------------------------------------------------------------------//
#include <stdio.h>
#include "applu.incl"
#include "../common/timers.h"
//---------------------------------------------------------------------
// to perform pseudo-time stepping SSOR iterations
// for five nonlinear pde's.
//---------------------------------------------------------------------
#include <omp.h> 

void ssor(int niter)
{
//---------------------------------------------------------------------
// local variables
//---------------------------------------------------------------------
  int i;
  int j;
  int k;
  int m;
  int n;
  int istep;
  double tmp;
  double tv[64][64][5];
  double delunm[5];
//---------------------------------------------------------------------
// begin pseudo-time stepping iterations
//---------------------------------------------------------------------
  tmp = 1.0 / (omega * (2.0 - omega));
//---------------------------------------------------------------------
// initialize a,b,c,d to zero (guarantees that page tables have been
// formed, if applicable on given architecture, before timestepping).
//---------------------------------------------------------------------
  
#pragma omp parallel for private (i,j,m,n)
  for (j = 0; j <= 63; j += 1) {
    
#pragma omp parallel for private (i,m,n)
    for (i = 0; i <= 63; i += 1) {
      
#pragma omp parallel for private (m,n)
      for (n = 0; n <= 4; n += 1) {
        
#pragma omp parallel for private (m)
        for (m = 0; m <= 4; m += 1) {
          a[j][i][n][m] = 0.0;
          b[j][i][n][m] = 0.0;
          c[j][i][n][m] = 0.0;
          d[j][i][n][m] = 0.0;
        }
      }
    }
  }
  for (i = 1; i <= 11; i += 1) {
    timer_clear(i);
  }
//---------------------------------------------------------------------
// compute the steady-state residuals
//---------------------------------------------------------------------
  rhs();
//---------------------------------------------------------------------
// compute the L2 norms of newton iteration residuals
//---------------------------------------------------------------------
  l2norm(64,64,64,nx0,ny0,nz0,ist,iend,jst,jend,rsd,rsdnm);
/*
  if ( ipr == 1 ) {
    printf("           Initial residual norms\n");
    printf("\n");
    printf(" \n RMS-norm of steady-state residual for "
           "first pde  = %12.5E\n"
           " RMS-norm of steady-state residual for "
           "second pde = %12.5E\n"
           " RMS-norm of steady-state residual for "
           "third pde  = %12.5E\n"
           " RMS-norm of steady-state residual for "
           "fourth pde = %12.5E\n"
           " RMS-norm of steady-state residual for "
           "fifth pde  = %12.5E\n", 
           rsdnm[0], rsdnm[1], rsdnm[2], rsdnm[3], rsdnm[4]);
    printf("\nIteration RMS-residual of 5th PDE\n");
  }
  */
  for (i = 1; i <= 11; i += 1) {
    timer_clear(i);
  }
  timer_start(1);
//---------------------------------------------------------------------
// the timestep loop
//---------------------------------------------------------------------
  for (istep = 1; istep <= niter; istep += 1) {
//if ( ( (istep % inorm) == 0 ) && ipr == 1 ) {
//  printf(" \n     pseudo-time SSOR iteration no.=%4d\n\n", istep);
//}
    if (istep % 20 == 0 || istep == itmax || istep == 1) {
      if (niter > 1) 
        printf(" Time step %4d\n",istep);
    }
//---------------------------------------------------------------------
// perform SSOR iteration
//---------------------------------------------------------------------
    if (timeron) 
      timer_start(5);
    
#pragma omp parallel for private (i,j,k,m)
    for (k = 1; k <= nz - 1 - 1; k += 1) {
      
#pragma omp parallel for private (i,j,m)
      for (j = jst; j <= jend - 1; j += 1) {
        
#pragma omp parallel for private (i,m)
        for (i = ist; i <= iend - 1; i += 1) {
          
#pragma omp parallel for private (m)
          for (m = 0; m <= 4; m += 1) {
            rsd[k][j][i][m] = dt * rsd[k][j][i][m];
          }
        }
      }
    }
    if (timeron) 
      timer_stop(5);
    for (k = 1; k <= nz - 1 - 1; k += 1) {
//---------------------------------------------------------------------
// form the lower triangular part of the jacobian matrix
//---------------------------------------------------------------------
      if (timeron) 
        timer_start(6);
      jacld(k);
      if (timeron) 
        timer_stop(6);
//---------------------------------------------------------------------
// perform the lower triangular solution
//---------------------------------------------------------------------
      if (timeron) 
        timer_start(7);
      blts(64,64,64,nx,ny,nz,k,omega,rsd,a,b,c,d,ist,iend,jst,jend,nx0,ny0);
      if (timeron) 
        timer_stop(7);
    }
    for (k = nz - 2; k >= 1; k += -1) {
//---------------------------------------------------------------------
// form the strictly upper triangular part of the jacobian matrix
//---------------------------------------------------------------------
      if (timeron) 
        timer_start(8);
      jacu(k);
      if (timeron) 
        timer_stop(8);
//---------------------------------------------------------------------
// perform the upper triangular solution
//---------------------------------------------------------------------
      if (timeron) 
        timer_start(9);
      buts(64,64,64,nx,ny,nz,k,omega,rsd,tv,d,a,b,c,ist,iend,jst,jend,nx0,ny0);
      if (timeron) 
        timer_stop(9);
    }
//---------------------------------------------------------------------
// update the variables
//---------------------------------------------------------------------
    if (timeron) 
      timer_start(10);
    
#pragma omp parallel for private (i,j,k,m)
    for (k = 1; k <= nz - 1 - 1; k += 1) {
      
#pragma omp parallel for private (i,j,m)
      for (j = jst; j <= jend - 1; j += 1) {
        
#pragma omp parallel for private (i,m)
        for (i = ist; i <= iend - 1; i += 1) {
          
#pragma omp parallel for private (m) firstprivate (tmp)
          for (m = 0; m <= 4; m += 1) {
            u[k][j][i][m] = u[k][j][i][m] + tmp * rsd[k][j][i][m];
          }
        }
      }
    }
    if (timeron) 
      timer_stop(10);
//---------------------------------------------------------------------
// compute the max-norms of newton iteration corrections
//---------------------------------------------------------------------
    if (istep % inorm == 0) {
      if (timeron) 
        timer_start(11);
      l2norm(64,64,64,nx0,ny0,nz0,ist,iend,jst,jend,rsd,delunm);
      if (timeron) 
        timer_stop(11);
/*
      if ( ipr == 1 ) {
        printf(" \n RMS-norm of SSOR-iteration correction "
               "for first pde  = %12.5E\n"
               " RMS-norm of SSOR-iteration correction "
               "for second pde = %12.5E\n"
               " RMS-norm of SSOR-iteration correction "
               "for third pde  = %12.5E\n"
               " RMS-norm of SSOR-iteration correction "
               "for fourth pde = %12.5E\n",
               " RMS-norm of SSOR-iteration correction "
               "for fifth pde  = %12.5E\n", 
               delunm[0], delunm[1], delunm[2], delunm[3], delunm[4]); 
      } else if ( ipr == 2 ) {
        printf("(%5d,%15.6f)\n", istep, delunm[4]);
      }
      */
    }
//---------------------------------------------------------------------
// compute the steady-state residuals
//---------------------------------------------------------------------
    rhs();
//---------------------------------------------------------------------
// compute the max-norms of newton iteration residuals
//---------------------------------------------------------------------
    if (istep % inorm == 0 || istep == itmax) {
      if (timeron) 
        timer_start(11);
      l2norm(64,64,64,nx0,ny0,nz0,ist,iend,jst,jend,rsd,rsdnm);
      if (timeron) 
        timer_stop(11);
/*
      if ( ipr == 1 ) {
        printf(" \n RMS-norm of steady-state residual for "
               "first pde  = %12.5E\n"
               " RMS-norm of steady-state residual for "
               "second pde = %12.5E\n"
               " RMS-norm of steady-state residual for "
               "third pde  = %12.5E\n"
               " RMS-norm of steady-state residual for "
               "fourth pde = %12.5E\n"
               " RMS-norm of steady-state residual for "
               "fifth pde  = %12.5E\n", 
               rsdnm[0], rsdnm[1], rsdnm[2], rsdnm[3], rsdnm[4]);
      }
      */
    }
//---------------------------------------------------------------------
// check the newton-iteration residuals against the tolerance levels
//---------------------------------------------------------------------
    if (rsdnm[0] < tolrsd[0] && rsdnm[1] < tolrsd[1] && rsdnm[2] < tolrsd[2] && rsdnm[3] < tolrsd[3] && rsdnm[4] < tolrsd[4]) {
//if (ipr == 1 ) {
      printf(" \n convergence was achieved after %4d pseudo-time steps\n",istep);
//}
      break; 
    }
  }
  timer_stop(1);
  maxtime = timer_read(1);
}
