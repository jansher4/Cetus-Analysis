//-------------------------------------------------------------------------//
//                                                                         //
//  This benchmark is a serial C version of the NPB SP code. This C        //
//  version is developed by the Center for Manycore Programming at Seoul   //
//  National University and derived from the serial Fortran versions in    //
//  "NPB3.3-SER" developed by NAS.                                         //
//                                                                         //
//  Permission to use, copy, distribute and modify this software for any   //
//  purpose with or without fee is hereby granted. This software is        //
//  provided "as is" without express or implied warranty.                  //
//                                                                         //
//  Information on NPB 3.3, including the technical report, the original   //
//  specifications, source code, results and information on how to submit  //
//  new results, is available at:                                          //
//                                                                         //
//           http://www.nas.nasa.gov/Software/NPB/                         //
//                                                                         //
//  Send comments or suggestions for this C version to cmp@aces.snu.ac.kr  //
//                                                                         //
//          Center for Manycore Programming                                //
//          School of Computer Science and Engineering                     //
//          Seoul National University                                      //
//          Seoul 151-744, Korea                                           //
//                                                                         //
//          E-mail:  cmp@aces.snu.ac.kr                                    //
//                                                                         //
//-------------------------------------------------------------------------//
//-------------------------------------------------------------------------//
// Authors: Sangmin Seo, Jungwon Kim, Jun Lee, Jeongho Nah, Gangwon Jo,    //
//          and Jaejin Lee                                                 //
//-------------------------------------------------------------------------//
//---------------------------------------------------------------------
// program SP
//---------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include "header.h"
#include "../common/print_results.h"
/* common /global/ */
int grid_points[3];
int nx2;
int ny2;
int nz2;
logical timeron;
/* common /constants/ */
double tx1;
double tx2;
double tx3;
double ty1;
double ty2;
double ty3;
double tz1;
double tz2;
double tz3;
double dx1;
double dx2;
double dx3;
double dx4;
double dx5;
double dy1;
double dy2;
double dy3;
double dy4;
double dy5;
double dz1;
double dz2;
double dz3;
double dz4;
double dz5;
double dssp;
double dt;
double ce[5][13];
double dxmax;
double dymax;
double dzmax;
double xxcon1;
double xxcon2;
double xxcon3;
double xxcon4;
double xxcon5;
double dx1tx1;
double dx2tx1;
double dx3tx1;
double dx4tx1;
double dx5tx1;
double yycon1;
double yycon2;
double yycon3;
double yycon4;
double yycon5;
double dy1ty1;
double dy2ty1;
double dy3ty1;
double dy4ty1;
double dy5ty1;
double zzcon1;
double zzcon2;
double zzcon3;
double zzcon4;
double zzcon5;
double dz1tz1;
double dz2tz1;
double dz3tz1;
double dz4tz1;
double dz5tz1;
double dnxm1;
double dnym1;
double dnzm1;
double c1c2;
double c1c5;
double c3c4;
double c1345;
double conz1;
double c1;
double c2;
double c3;
double c4;
double c5;
double c4dssp;
double c5dssp;
double dtdssp;
double dttx1;
double bt;
double dttx2;
double dtty1;
double dtty2;
double dttz1;
double dttz2;
double c2dttx1;
double c2dtty1;
double c2dttz1;
double comz1;
double comz4;
double comz5;
double comz6;
double c3c4tx3;
double c3c4ty3;
double c3c4tz3;
double c2iv;
double con43;
double con16;
/* common /fields/ */
double u[64][65][65][5];
double us[64][65][65];
double vs[64][65][65];
double ws[64][65][65];
double qs[64][65][65];
double rho_i[64][65][65];
double speed[64][65][65];
double square[64][65][65];
double rhs[64][65][65][5];
double forcing[64][65][65][5];
/* common /work_1d/ */
double cv[64];
double rhon[64];
double rhos[64];
double rhoq[64];
double cuf[64];
double q[64];
double ue[64][5];
double buf[64][5];
/* common /work_lhs/ */
double lhs[65][65][5];
double lhsp[65][65][5];
double lhsm[65][65][5];

int main(int argc,char *argv[])
{
  int i;
  int niter;
  int step;
  int n3;
  double mflops;
  double t;
  double tmax;
  double trecs[16];
  logical verified;
  char Class;
  char *t_names[16];
//---------------------------------------------------------------------
// Read input file (if it exists), else take
// defaults from parameters
//---------------------------------------------------------------------
  FILE *fp;
  if ((fp = fopen("timer.flag","r")) != ((void *)0)) {
    timeron = true;
    t_names[1] = "total";
    t_names[2] = "rhsx";
    t_names[3] = "rhsy";
    t_names[4] = "rhsz";
    t_names[5] = "rhs";
    t_names[6] = "xsolve";
    t_names[7] = "ysolve";
    t_names[8] = "zsolve";
    t_names[9] = "redist1";
    t_names[10] = "redist2";
    t_names[14] = "tzetar";
    t_names[13] = "ninvr";
    t_names[12] = "pinvr";
    t_names[11] = "txinvr";
    t_names[15] = "add";
    fclose(fp);
  }
   else {
    timeron = false;
  }
  printf("\n\n NAS Parallel Benchmarks (NPB3.3-SER-C) - SP Benchmark\n\n");
  if ((fp = fopen("inputsp.data","r")) != ((void *)0)) {
    int result;
    printf(" Reading from input file inputsp.data\n");
    result = fscanf(fp,"%d",&niter);
    while(fgetc(fp) != '\n')
      ;
    result = fscanf(fp,"%lf",&dt);
    while(fgetc(fp) != '\n')
      ;
    result = fscanf(fp,"%d%d%d",&grid_points[0],&grid_points[1],&grid_points[2]);
    fclose(fp);
  }
   else {
    printf(" No input file inputsp.data. Using compiled defaults\n");
    niter = 400;
    dt = 0.0015;
    grid_points[0] = 64;
    grid_points[1] = 64;
    grid_points[2] = 64;
  }
  printf(" Size: %4dx%4dx%4d\n",grid_points[0],grid_points[1],grid_points[2]);
  printf(" Iterations: %4d    dt: %10.6f\n",niter,dt);
  printf("\n");
  if (grid_points[0] > 64 || grid_points[1] > 64 || grid_points[2] > 64) {
    printf(" %d, %d, %d\n",grid_points[0],grid_points[1],grid_points[2]);
    printf(" Problem size too big for compiled array sizes\n");
    return 0;
  }
  nx2 = grid_points[0] - 2;
  ny2 = grid_points[1] - 2;
  nz2 = grid_points[2] - 2;
  set_constants();
  for (i = 1; i <= 15; i += 1) {
    timer_clear(i);
  }
  exact_rhs();
  initialize();
//---------------------------------------------------------------------
// do one time step to touch all code, and reinitialize
//---------------------------------------------------------------------
  adi();
  initialize();
  for (i = 1; i <= 15; i += 1) {
    timer_clear(i);
  }
  timer_start(1);
  for (step = 1; step <= niter; step += 1) {
    if (step % 20 == 0 || step == 1) {
      printf(" Time step %4d\n",step);
    }
    adi();
  }
  timer_stop(1);
  tmax = timer_read(1);
  verify(niter,&Class,&verified);
  if (tmax != 0.0) {
    n3 = grid_points[0] * grid_points[1] * grid_points[2];
    t = (grid_points[0] + grid_points[1] + grid_points[2]) / 3.0;
    mflops = (881.174 * ((double )n3) - 4683.91 * (t * t) + 11484.5 * t - 19272.4) * ((double )niter) / (tmax * 1000000.0);
  }
   else {
    mflops = 0.0;
  }
  print_results("SP",Class,grid_points[0],grid_points[1],grid_points[2],niter,tmax,mflops,"          floating point",verified,"3.3.1","26 Apr 2020","gcc","$(CC)","-lm","-I../common","-g -Wall -O3 -fopenmp -mcmodel=medium","-O3 -fopenmp -mcmodel=medium","(none)");
//---------------------------------------------------------------------
// More timers
//---------------------------------------------------------------------
  if (timeron) {
    for (i = 1; i <= 15; i += 1) {
      trecs[i] = timer_read(i);
    }
    if (tmax == 0.0) 
      tmax = 1.0;
    printf("  SECTION   Time (secs)\n");
    for (i = 1; i <= 15; i += 1) {
      printf("  %-8s:%9.3f  (%6.2f%%)\n",t_names[i],trecs[i],trecs[i] * 100. / tmax);
      if (i == 5) {
        t = trecs[2] + trecs[3] + trecs[4];
        printf("    --> %8s:%9.3f  (%6.2f%%)\n","sub-rhs",t,t * 100. / tmax);
        t = trecs[5] - t;
        printf("    --> %8s:%9.3f  (%6.2f%%)\n","rest-rhs",t,t * 100. / tmax);
      }
       else if (i == 8) {
        t = trecs[8] - trecs[9] - trecs[10];
        printf("    --> %8s:%9.3f  (%6.2f%%)\n","sub-zsol",t,t * 100. / tmax);
      }
       else if (i == 10) {
        t = trecs[9] + trecs[10];
        printf("    --> %8s:%9.3f  (%6.2f%%)\n","redist",t,t * 100. / tmax);
      }
    }
  }
  return 0;
}
