// A test case of a non-canonical loop.
// Naively putting openmp parallel for for it is wrong.
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include<omp.h>
static int a[53100000];
static int b[53100000];
static int c[53100000];

int main()
{
  int i;
  int j;
  int k;
  j = 0;
  int len = 53100000;
  double ctime1 = omp_get_wtime();
  for (i = 0; i <= len - 1; i += 1) {
    b[j] += c[i] + a[j];
    j++;
  }
  double ctime2 = omp_get_wtime();
  printf("\nCtimeSec  %f\n\n",ctime2 - ctime1);
  return 0;
}
