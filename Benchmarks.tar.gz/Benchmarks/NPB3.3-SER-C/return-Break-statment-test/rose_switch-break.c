// A test case of a non-canonical loop.
// Naively putting openmp parallel for for it is wrong.
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include<omp.h>
#include <omp.h> 
static int a[531000000];
static int b[531000000];

int main()
{
  int i;
  int j;
  j = 20000;
  int limit = 531000000;
  double ctime1 = omp_get_wtime();
//#pragma omp parallel for private (i) reduction (+:j)
  
#pragma omp parallel for private (j,i) firstprivate (limit)
  for (i = 0; i <= limit - 1; i += 1) {
    switch('A'){
      case 'S':
      if (b[i] == 0) {
        j = 6 + i;
        break; 
        case 'A':
        b[i] = i + 5;
        break; 
        case 'W':
        b[i] = i + 7;
        break; 
        case 'B':
        b[i] = i * i + 1;
        break; 
        case 'C':
        b[i] = i + 4;
        break; 
        case 'D':
        b[i] = i + 3;
        break; 
      }
//if(b[i] == 0){
//j = j+ i;
//j--; // this is interesting line
//printf("Hello its if statement true");
//break;
//return 0;
    }
  }
  double ctime2 = omp_get_wtime();
  printf("\nCtimeSec  %f\n\n",ctime2 - ctime1);
  return 0;
}
///*
///*
/*
int main()
{
  int i,j;
  int limit =531000000;
double ctime1 = omp_get_wtime();
#pragma omp parallel for private (i) num_threads(4)
  for (i = 0; i < limit ; i++ )
  {
	//j = i; 
    b[i]=a[i];
  }
	double ctime2 = omp_get_wtime();
	printf("\nCtimeSec  %f\n\n", ctime2 - ctime1);
  return 0;
}
*/
