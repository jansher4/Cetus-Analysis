import os
#coding: utf-8
import nltk
from shutil import copy
from nltk import ngrams
from nltk import FreqDist
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import numpy as np
import operator
import sys
from collections import Counter
import numpy
import itertools
import csv
import json
import time

rosepath = "/home/jansher/build-rose/projects/autoParallelization/./autoPar -c"
cetuspath= '/home/jansher/Documents/cetus-1.4.4/bin/./cetus -profitable-omp=1 -parallelize-loops=4 -c'
text_file = open("list.txt", "r")
lines = text_file.read()
lines = lines.split()


Counter = 1
for i in lines:
	print Counter
	rose_counter = 0
	cetus_counter = 0
	#os.system(rosepath+ ' /home/jansher/Desktop/tests-algo-wilson/'+str(lines))
	#os.system(cetuspath+ ' /home/jansher/Desktop/tests-algo-wilson/'+str(lines))
	start = time.clock()
	os.system('/home/jansher/build-rose/projects/autoParallelization/./autoPar -c /home/jansher/Desktop/tests-algo-wilson/'+str(i))
	start = (time.clock() - start)

	file = open("rose_"+str(i), "r")
	rosefile = file.read()
	rosefile = rosefile.split()
	for r in rosefile:
		if r == 'parallel':
			rose_counter +=1
		

	#loc = len(lines)-1
	#i[(len(i)-1)] = 'o'
	#print lines[0]
	os.system('rm '+str(i[0:(len(i)-1)])+'o')

	start1 = time.clock()
	os.system('/home/jansher/Documents/cetus-1.4.4/bin/./cetus -profitable-omp=1 -parallelize-loops=4 -c /home/jansher/Desktop/tests-algo-wilson/'+str(i))
	#os.system('clear')
	start1 = time.clock() - start1
	
	try:
		
		f = open("/home/jansher/Desktop/Wilson3/cetus_output/"+str(i), "r")
		cetusfile = f.read()
		cetusfile = cetusfile.split()
		for c in cetusfile:
			if c == 'parallel':
				cetus_counter +=1
	except:
		pass

	with open('data.csv','a') as scorefile:#======== CSV writer
            scorefilewriter = csv.writer(scorefile)
            scorefilewriter.writerow([str(i),start,start1,rose_counter, cetus_counter])
        scorefile.close()
	Counter += 1


'''
for i in range(0,22):
	print i
	start = time.clock()
	os.system('/home/jansher/build-rose/projects/autoParallelization/./autoPar -c /home/jansher/Desktop/Test1/Cetus-master/test'+str(i)+'.c')
	start = (time.clock() - start)	
	print ("Rose time ="+ str(time.clock() - start))
	os.system('rm test'+str(i)+'.o')
	start1 = time.clock()
	os.system('/home/jansher/Documents/cetus-1.4.4/bin/./cetus -profitable-omp=1 -parallelize-loops=4 -c /home/jansher/Desktop/Test1/Cetus-master/test'+str(i)+'.c')
	start1 = time.clock() - start1
	print ("Cetus time ="+ str(time.clock() - start))
	with open('data.csv','a') as scorefile:#======== CSV writer
            scorefilewriter = csv.writer(scorefile)
            scorefilewriter.writerow(['test'+str(i)+'.c','rosetime',start,'cetustime',start1])
        scorefile.close()

'''
#gcc -fopenmp anyname.c -o anyname.out
#./anyname.out



#/home/jansher/build-rose/projects/autoParallelization/./autoPar -c test1.c

