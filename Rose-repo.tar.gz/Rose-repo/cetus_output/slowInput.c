/*
Copyright (C) 1991-2016 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it andor
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <http:www.gnu.org/licenses/>. 
*/
/*
This header is separate from features.h so that the compiler can
   include it implicitly at the start of every compilation.  It must
   not itself include <features.h> or any other header that includes
   <features.h> because the implicit include comes before any feature
   test macros that may be defined in a source file before it first
   explicitly includes a system header.  GCC knows the name of this
   header in order to preinclude it. 
*/
/*
glibc's intent is to support the IEC 559 math functionality, real
   and complex.  If the GCC (4.9 and later) predefined macros
   specifying compiler intent are available, use them to determine
   whether the overall intent is to support these features; otherwise,
   presume an older compiler has intent to support these features and
   define these macros by default. 
*/
/*
wchar_t uses Unicode 8.0.0.  Version 8.0 of the Unicode Standard is
   synchronized with ISOIEC 10646:2014, plus Amendment 1 (published
   2015-05-15). 
*/
/* We do not support C11 <threads.h>.  */
typedef double real8;
/*

 * Function  : StressZero
 * 
 * Purpose   : 

*/
void StressZero(real8 * newSxx, real8 * newSyy, real8 * newSzz, real8 * newTxy, real8 * newTxz, real8 * newTyz, const real8 * fun2j, const real8 * shearMod, real8 eosvmax, real8 stresscut, const int * zoneset, const real8 * vc, int length)
{
	int i, index;
	/*
	This value 1.e-20 is used to prevent underflow. It is NOT a
	     cuttoff. DO NOT TOUCH THIS VALE.
	*/
	real8 stress2 = stresscut*1.0E-20;
	real8 nstres2 =  - stress2;
	#pragma loop name StressZero#0 
	for (i=0; i<length; i ++ )
	{
		index=zoneset[i];
		if (((shearMod[index]==0.0)||(fun2j[i]<stresscut))||(vc[i]>=eosvmax))
		{
			newSxx[i]=0.0;
			newSyy[i]=0.0;
			newSzz[i]=0.0;
			newTxy[i]=0.0;
			newTxz[i]=0.0;
			newTyz[i]=0.0;
		}
		if ((newSxx[i]<stress2)&&(newSxx[i]>nstres2))
		{
			newSxx[i]=0.0;
		}
		if ((newSyy[i]<stress2)&&(newSyy[i]>nstres2))
		{
			newSyy[i]=0.0;
		}
		if ((newSzz[i]<stress2)&&(newSzz[i]>nstres2))
		{
			newSzz[i]=0.0;
		}
		if ((newTxy[i]<stress2)&&(newTxy[i]>nstres2))
		{
			newTxy[i]=0.0;
		}
		if ((newTxz[i]<stress2)&&(newTxz[i]>nstres2))
		{
			newTxz[i]=0.0;
		}
		if ((newTyz[i]<stress2)&&(newTyz[i]>nstres2))
		{
			newTyz[i]=0.0;
		}
	}
	return ;
}
