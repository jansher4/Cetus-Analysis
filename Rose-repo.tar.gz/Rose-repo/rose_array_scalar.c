
void foo()
{
  int i;
  int a[100];
  for (i = 0; i <= 99; i += 1) {
    a[i] = a[i] + a[0];
  }
}
/*  
 */
